# 静签 Special V2.5 源码包

本压缩包对应 `special-v2.5` Release 中的 `QuietSign-Special-V2.5.apk`。

- 包名：`com.gduf.chuxiao.special`
- 版本：`V2.5 / code 25`
- 源码文件：`src/com/gduf/chuxiao/special/`，共 10 个
- 构建：Windows 下执行 `pwsh ./build.ps1 -VersionName V2.5 -VersionCode 25`；Linux / macOS 使用 `build.sh`
- 签名：仓库不含私钥；请复制 `keystore.properties.example` 为 `keystore.properties`，填入自己的密钥库与口令后再签名
- 依赖：Android SDK（`build-tools`、`platforms/android-*`）与 JDK 11+；`libs/zxing-core-3.5.3.jar` 已随包附带
- 图标：蓝底白色「清单 + 勾」，`res/drawable` 与 `res/mipmap-*` 已包含

服务端脚本 `server/` 不在此包内。它与客户端无关，且已废弃，仅供协议研究。
