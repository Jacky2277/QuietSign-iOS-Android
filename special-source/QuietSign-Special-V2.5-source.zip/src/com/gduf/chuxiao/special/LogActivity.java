package com.gduf.chuxiao.special;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 运行日志页：只读展示 + 复制 / 分享 / 清空，配色与签到考勤一致。 */
public class LogActivity extends Activity {

    boolean night = false;
    int cBg, cCard, cInk, cSub, cPrimary, cCont, cLine, cMuted;

    TextView logView;
    ScrollView scroll;

    void applyTheme() {
        int mode = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        night = mode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            cBg = 0xFF101318; cCard = 0xFF1C2129; cInk = 0xFFE8ECF2; cSub = 0xFF8E99A8;
            cPrimary = 0xFF4D86FF; cCont = 0xFF1E2A44; cLine = 0xFF2A3038; cMuted = 0xFF6E7886;
        } else {
            cBg = 0xFFF4F7FC; cCard = 0xFFFFFFFF; cInk = 0xFF1A1D23; cSub = 0xFF7A8494;
            cPrimary = 0xFF2F6BFF; cCont = 0xFFE8EFFF; cLine = 0xFFEBF0F7; cMuted = 0xFFA8B2C0;
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        recreate();
    }

    @Override
    public void finish() {
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, R.anim.stay, R.anim.slide_down_out);
        }
        super.finish();
        if (Build.VERSION.SDK_INT < 34) {
            overridePendingTransition(R.anim.stay, R.anim.slide_down_out);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Logx.init(this);
        applyTheme();
        try {
            getWindow().setStatusBarColor(cBg);
            getWindow().getDecorView().setSystemUiVisibility(night ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } catch (Exception ignored) {
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cBg);
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(cCard);
        bar.setElevation(dp(2));
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        TextView back = tv("‹ 返回", 15, cSub, false);
        back.setPadding(dp(2), dp(6), dp(14), dp(6));
        back.setOnClickListener(v -> finish());
        bar.addView(back);

        TextView title = tv("运行日志", 18, cInk, true);
        title.setGravity(Gravity.CENTER);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView clear = tv("清空", 14, cPrimary, false);
        clear.setPadding(dp(14), dp(6), dp(2), dp(6));
        clear.setOnClickListener(v -> confirmClear());
        bar.addView(clear);

        scroll = new ScrollView(this);
        scroll.setBackgroundColor(cBg);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(dp(16), dp(14), dp(16), dp(14));
        scroll.addView(pad, new LinearLayout.LayoutParams(-1, -2));

        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setTextColor(cInk);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setLineSpacing(dp(2), 1f);
        logView.setTextIsSelectable(true);
        GradientDrawable lg = new GradientDrawable();
        lg.setColor(cCard);
        lg.setCornerRadius(dp(16));
        lg.setStroke(dp(1), cLine);
        logView.setBackground(lg);
        logView.setPadding(dp(14), dp(14), dp(14), dp(14));
        pad.addView(logView, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout acts = new LinearLayout(this);
        acts.setOrientation(LinearLayout.HORIZONTAL);
        acts.setClipChildren(false);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, dp(48));
        alp.topMargin = dp(12);
        pad.addView(acts, alp);

        Button copy = pill("复制全部", cPrimary, 24, 15);
        acts.addView(copy, new LinearLayout.LayoutParams(0, dp(48), 1));
        copy.setOnClickListener(v -> copyAll());

        View gap = new View(this);
        acts.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));

        Button share = pill("分享", cPrimary, 24, 15);
        acts.addView(share, new LinearLayout.LayoutParams(0, dp(48), 1));
        share.setOnClickListener(v -> shareLog());

        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    void load() {
        String s = Logx.dump();
        if (s == null || s.trim().isEmpty()) {
            logView.setTextColor(cMuted);
            logView.setText("还没有日志。\n\n复现问题时，回到首页重新登录 / 签到，再来这里查看。");
        } else {
            logView.setTextColor(cInk);
            logView.setText(s);
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    void copyAll() {
        String s = Logx.dump();
        if (s == null || s.isEmpty()) {
            Toast.makeText(this, "没有日志可复制", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("QuietSign log", s));
            Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "复制失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    void shareLog() {
        String s = Logx.dump();
        if (s == null || s.isEmpty()) {
            Toast.makeText(this, "没有日志可分享", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent it = new Intent(Intent.ACTION_SEND);
        it.setType("text/plain");
        it.putExtra(Intent.EXTRA_SUBJECT, "静签运行日志");
        it.putExtra(Intent.EXTRA_TEXT, s);
        try {
            startActivity(Intent.createChooser(it, "分享日志"));
        } catch (Throwable t) {
            Toast.makeText(this, "分享失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    void confirmClear() {
        final android.app.Dialog d = new android.app.Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(20), dp(24), dp(20), dp(24));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cCard);
        bg.setCornerRadius(dp(24));
        box.setBackground(bg);
        box.setPadding(dp(22), dp(22), dp(22), dp(16));
        box.setElevation(dp(10));

        box.addView(tv("清空运行日志？", 19, cInk, true));
        TextView msg = tv("清空后无法恢复，但不会影响账号和签到数据。", 13, cSub, false);
        msg.setPadding(0, dp(10), 0, dp(16));
        box.addView(msg);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END);
        Button cancel = pill("取消", cCont, 22, 14);
        cancel.setTextColor(cInk);
        row.addView(cancel, new LinearLayout.LayoutParams(dp(88), dp(40)));
        View gap2 = new View(this);
        row.addView(gap2, new LinearLayout.LayoutParams(dp(8), 1));
        Button ok = pill("清空", cPrimary, 22, 14);
        row.addView(ok, new LinearLayout.LayoutParams(dp(96), dp(40)));
        box.addView(row);

        wrap.addView(box, new LinearLayout.LayoutParams((int) (getResources().getDisplayMetrics().widthPixels * 0.86), -2));
        d.setContentView(wrap);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            d.getWindow().setDimAmount(0.45f);
        }
        cancel.setOnClickListener(v -> d.dismiss());
        ok.setOnClickListener(v -> {
            d.dismiss();
            Logx.clear();
            load();
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
        });
        d.show();
    }

    int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    Button pill(String s, int color, float radiusDp, float size) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(size);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        b.setBackground(g);
        b.setPadding(0, 0, 0, 0);
        try {
            b.setStateListAnimator(null);
            b.setElevation(0);
        } catch (Throwable ignored) {
        }
        return b;
    }
}
