package com.gduf.chuxiao.special;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Locale;

/**
 * 运行日志：内存环形缓冲 + 落盘 run.log，供首页「运行日志」页查看、复制、分享。
 * 只记流程与状态码，不记密码/token 明文。
 */
final class Logx {

    private static final int MAX_LINES = 3000;
    private static final long MAX_BYTES = 512 * 1024;
    private static final Object LOCK = new Object();
    private static final Deque<String> MEM = new ArrayDeque<>();
    private static final SimpleDateFormat TS = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US);
    private static File file;

    private Logx() { }

    static void init(Context c) {
        synchronized (LOCK) {
            if (file != null) return;
            try {
                file = new File(c.getFilesDir(), "run.log");
                if (file.exists() && file.length() > 0) {
                    String all = readAll(file);
                    for (String ln : all.split("\n")) if (!ln.trim().isEmpty()) addMem(ln);
                    if (file.length() > MAX_BYTES) trim();
                }
            } catch (Throwable ignored) { }
        }
        i("app", "日志启动 v" + MainActivity.VERSION);
    }

    static void i(String tag, String msg) { write("I", tag, msg, null); }

    static void w(String tag, String msg) { write("W", tag, msg, null); }

    static void e(String tag, String msg, Throwable t) {
        String extra = "";
        if (t != null) {
            extra = " | " + t.getClass().getSimpleName() + ": " + t.getMessage();
        }
        write("E", tag, msg + extra, null);
    }

    private static void write(String lv, String tag, String msg, Throwable t) {
        String line;
        synchronized (LOCK) {
            line = TS.format(new Date()) + " " + lv + "/" + tag + " " + oneLine(msg);
            addMem(line);
            append(line);
        }
    }

    private static String oneLine(String s) {
        if (s == null) return "";
        String v = s.replace("\r", " ").replace("\n", " ⏎ ");
        return v.length() > 4000 ? v.substring(0, 4000) + "…" : v;
    }

    private static void addMem(String line) {
        MEM.addLast(line);
        while (MEM.size() > MAX_LINES) MEM.removeFirst();
    }

    private static void append(String line) {
        if (file == null) return;
        try {
            FileOutputStream fos = new FileOutputStream(file, true);
            fos.write((line + "\n").getBytes("UTF-8"));
            fos.close();
            if (file.length() > MAX_BYTES) trim();
        } catch (Throwable ignored) { }
    }

    private static void trim() {
        try {
            String all = readAll(file);
            int keep = all.length() / 2;
            if (keep > all.length()) keep = 0;
            String tail = all.substring(keep);
            int nl = tail.indexOf('\n');
            if (nl > 0) tail = tail.substring(nl + 1);
            FileOutputStream fos = new FileOutputStream(file, false);
            fos.write(tail.getBytes("UTF-8"));
            fos.close();
        } catch (Throwable ignored) { }
    }

    private static String readAll(File f) throws Exception {
        FileInputStream fis = new FileInputStream(f);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
        fis.close();
        return new String(bos.toByteArray(), "UTF-8");
    }

    /** 返回当前全部日志（内存缓冲优先，最多 3000 行）。 */
    static String dump() {
        synchronized (LOCK) {
            StringBuilder sb = new StringBuilder();
            for (String ln : MEM) sb.append(ln).append('\n');
            return sb.toString();
        }
    }

    static void clear() {
        synchronized (LOCK) {
            MEM.clear();
            if (file != null) {
                try {
                    new FileOutputStream(file, false).close();
                } catch (Throwable ignored) { }
            }
        }
        i("app", "日志已清空");
    }

    /** 供分享用的文件；没有日志时返回 null。 */
    static File exportFile(Context c) {
        synchronized (LOCK) {
            if (MEM.isEmpty()) return null;
            try {
                File out = new File(c.getCacheDir(), "QuietSign-log.txt");
                FileOutputStream fos = new FileOutputStream(out, false);
                for (String ln : MEM) fos.write((ln + "\n").getBytes("UTF-8"));
                fos.close();
                return out;
            } catch (Throwable t) {
                return null;
            }
        }
    }
}
