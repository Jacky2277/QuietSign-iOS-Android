package com.gduf.chuxiao.special;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.ContentValues;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    static final String UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 yiban_iOS/5.2.5(5104)";
    static final String BASE = "https://ygj.gduf.edu.cn";
    static final int GREEN = 0xFF78B842;
    static final int REQ_LOGIN = 21;
    static final int REQ_SIGN = 22;

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SIGN && res == RESULT_OK && data != null) {
            String section = data.getStringExtra("section");
            String time = data.getStringExtra("time");
            int count = data.getIntExtra("count", 1);
            showHome();
            showSignSuccessSnackbar(section, time, count);
            return;
        }
        if (req != REQ_LOGIN) return;
        if (res != RESULT_OK || data == null) {
            if (setupHint != null) setupHint.setText("已取消易班登录");
            return;
        }
        String t = data.getStringExtra("token");
        String v = data.getStringExtra("verify");
        if (t == null || t.trim().isEmpty()) {
            if (setupHint != null) {
                setupHint.setText("没有拿到登录 token。可以重试一次，或用下方的粘贴 token 方式。");
            }
            return;
        }
        sp.edit().putString("userToken", t.trim()).apply();
        if (v != null && !v.isEmpty()) sp.edit().putString("verifyOnce", v).apply();
        showHome();
    }

    @Override
    public void onBackPressed() {
        if (qrPage) { showHome(); return; }
        super.onBackPressed();
    }

    SharedPreferences sp;
    final Handler ui = new Handler(Looper.getMainLooper());
    LinearLayout root;
    ScrollView scroll;
    LinearLayout shell, bottomBar;

    // QR screen
    TextView titleView, nameView, countdownView, statusView, qrUseView;
    ImageView qrView;
    CornerFrame corners;
    Button refreshBtn, overdueBtn, changeBtn, signBtn;
    TextView placeholder;
    Bitmap lastQrBitmap;
    volatile long endAt = 0;
    volatile boolean lastInbound = false;
    boolean qrPage = false;
    boolean qrInbound = false;
    TextView qrSegOut, qrSegIn;

    // setup screen
    EditText tokenInput;
    TextView setupHint;

    final Map<String, String> cookies = new HashMap<>();
    String studentID = "";
    String outSchoolID = "";
    String recType = "出";
    String lastName = "", lastStart = "", lastEnd = "";
    volatile boolean busy = false;
    volatile int gen = 0;
    volatile long nextRefreshAt = 0;

    static final String VERSION = "V2.5";
    boolean night = false;
    int cBg, cCard, cInk, cSub, cSec, cPrimary, cCont, cLine, cMuted;
    int cInk2, cInk3, cInk4, cAccentSoft, cOk, cOkSoft, cWarn, cWarnSoft, cDanger, cDangerSoft, cQrBg;
    TextView stateChip;
    // 首页设备状态条
    TextView homeStripText;
    YgjClient.DeviceStatus lastStatus = null;
    ProgressBar progBar;

    void applyTheme() {
        int mode = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        night = mode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            cBg = 0xFF101318; cCard = 0xFF1C2129; cInk = 0xFFE8ECF2; cSub = 0xFF8E99A8;
            cSec = 0xFF96A2B2; cPrimary = 0xFF4D86FF; cCont = 0xFF1E2A44; cLine = 0xFF2A3038;
            cMuted = 0xFF6E7886;
            cInk2 = 0xFFB9C3D1; cInk3 = 0xFF8E99A8; cInk4 = 0xFF6E7886;
            cAccentSoft = 0xFF1E2A44; cOk = 0xFF3DD68C; cOkSoft = 0xFF143326;
            cWarn = 0xFFFFB86B; cWarnSoft = 0xFF3A2A16; cDanger = 0xFFFF7B72; cDangerSoft = 0xFF3A1E1C;
            cQrBg = 0xFF101318;
        } else {
            cBg = 0xFFF2F5FA; cCard = 0xFFFFFFFF; cInk = 0xFF0E1626; cSub = 0xFF8B95A5;
            cSec = 0xFF5C6779; cPrimary = 0xFF2F6BFF; cCont = 0xFFEFF3FE; cLine = 0xFFE7ECF4;
            cMuted = 0xFFA6AFBE;
            cInk2 = 0xFF4A5568; cInk3 = 0xFF8B95A5; cInk4 = 0xFFA6AFBE;
            cAccentSoft = 0xFFEFF3FE; cOk = 0xFF079455; cOkSoft = 0xFFE7F6EE;
            cWarn = 0xFFB45309; cWarnSoft = 0xFFFFF7E6; cDanger = 0xFFD92D20; cDangerSoft = 0xFFFEF3F2;
            cQrBg = 0xFFEEF3FA;
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        applyTheme();
        if (root != null) root.setBackgroundColor(cBg);
        if (token().isEmpty()) showSetup(false);
        else showHome();
    }

    static class Resp {
        int code;
        String body = "";
        String location = null;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", 0);
        Logx.init(this);
        Logx.i("app", "首页启动 " + VERSION + " Special · " + Build.MANUFACTURER + ":" + Build.MODEL
                + " · Android " + Build.VERSION.RELEASE);
        applyTheme();
        try {
            getWindow().setStatusBarColor(cBg);
            getWindow().getDecorView().setSystemUiVisibility(night ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } catch (Exception ignored) {
        }
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cBg);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root, new ViewGroup.LayoutParams(-1, -2));
        scroll.setBackgroundColor(cBg);

        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(shell);
        if (token().isEmpty()) showSetup(false);
        else showHome();
    }

    String token() { return sp.getString("userToken", ""); }

    static String clean(String s) {
        return s == null ? "" : s.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
    }

    int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(dp(4), 1f);
        return t;
    }

    Button btn(String s, int bg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(bg);
        return b;
    }

    GradientDrawable bg(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    Button pill(String s, int color, float radiusDp, float size) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(size);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(bg(color, radiusDp));
        try {
            b.setStateListAnimator(null);
            b.setElevation(0);
        } catch (Throwable ignored) {
        }
        return b;
    }

    void clearRoot() { root.removeAllViews(); removeBottomBar(); }

    void removeBottomBar() {
        if (bottomBar != null && shell != null) shell.removeView(bottomBar);
        bottomBar = null;
    }

    void installFooter(LinearLayout bar) {
        removeBottomBar();
        bottomBar = bar;
        shell.addView(bottomBar, new LinearLayout.LayoutParams(-1, -2));
    }

    /** 二维码四角 L 框，间距固定（浅色/深色一致） */
    static class CornerFrame extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float inset, len;

        CornerFrame(Context c, int color) {
            super(c);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(color);
            float d = c.getResources().getDisplayMetrics().density;
            p.setStrokeWidth(2.5f * d);
            inset = 10f * d;
            len = 22f * d;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float i = inset, L = len, s = p.getStrokeWidth() / 2f;
            float w = getWidth(), h = getHeight();
            cv.drawLine(i, i + s, i + L, i + s, p);
            cv.drawLine(i + s, i, i + s, i + L, p);
            cv.drawLine(w - i - L, i + s, w - i, i + s, p);
            cv.drawLine(w - i - s, i, w - i - s, i + L, p);
            cv.drawLine(i, h - i - s, i + L, h - i - s, p);
            cv.drawLine(i + s, h - i - L, i + s, h - i, p);
            cv.drawLine(w - i - L, h - i - s, w - i, h - i - s, p);
            cv.drawLine(w - i - s, h - i - L, w - i - s, h - i, p);
        }
    }

    // ---------------- m3 helpers ----------------

    LinearLayout card() { return card(24); }

    LinearLayout card(float radiusDp) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = bg(cCard, radiusDp);
        g.setStroke(dp(1), cLine);
        c.setBackground(g);
        return c;
    }

    Button flatBtn(String s, int bgColor, int fgColor, float radiusDp, float size) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(size);
        b.setTextColor(fgColor);
        b.setAllCaps(false);
        b.setBackground(bg(bgColor, radiusDp));
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        try {
            b.setStateListAnimator(null);
            b.setElevation(0);
        } catch (Throwable ignored) {
        }
        return b;
    }

    Button borderBtn(String s) {
        Button b = flatBtn(s, cCard, cSec, 999, 11);
        GradientDrawable g = bg(cCard, 999);
        g.setStroke(dp(1), cLine);
        b.setBackground(g);
        return b;
    }

    void gap(LinearLayout parent, float h) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(-1, dp(h)));
    }

    void setBarColors(int bg, int nav) {
        try {
            getWindow().setStatusBarColor(bg);
            getWindow().setNavigationBarColor(nav);
            getWindow().getDecorView().setSystemUiVisibility(night ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } catch (Exception ignored) {
        }
    }

    LinearLayout appBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(tv("静签", 21, cInk, true));
        String sub = studentID.isEmpty() ? "广东金融学院" : ("广东金融学院 · " + studentID);
        TextView s = tv(sub, 11, cSub, false);
        s.setPadding(0, dp(2), 0, 0);
        col.addView(s);
        bar.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        // 运行日志：字体按钮，风格与 iOS 首页「签到考勤」一致，放在右上角 ⋮ 左侧
        TextView logBtn = tv("运行日志", 13, cSub, false);
        logBtn.setPadding(dp(10), dp(8), dp(8), dp(8));
        logBtn.setOnClickListener(v -> openLogs());
        bar.addView(logBtn);
        TextView more = tv("···", 20, cSub, false);
        more.setPadding(dp(16), dp(6), dp(6), dp(6));
        more.setOnClickListener(v -> showAbout());
        bar.addView(more);
        return bar;
    }

    /** 打开运行日志页，转场与「签到考勤」完全一致。 */
    void openLogs() {
        Intent it = new Intent(this, LogActivity.class);
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, R.anim.slide_up_in, R.anim.stay);
        }
        startActivity(it);
        if (Build.VERSION.SDK_INT < 34) {
            overridePendingTransition(R.anim.slide_up_in, R.anim.stay);
        }
    }

    TextView sectionHead(String s) {
        TextView t = tv(s, 13, cSec, false);
        t.setPadding(0, dp(20), 0, dp(8));
        return t;
    }

    Button chipBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(cPrimary);
        b.setBackground(bg(cCont, 24));
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        try {
            b.setStateListAnimator(null);
            b.setElevation(0);
        } catch (Throwable ignored) {
        }
        return b;
    }

    LinearLayout listRow(String icon, boolean filled, String title, String sub, Runnable onClick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(12), 0, dp(12));
        TextView ic = tv(icon, 15, filled ? 0xFFFFFFFF : cPrimary, true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(bg(filled ? cPrimary : cCont, 12));
        row.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), 0, dp(8), 0);
        col.addView(tv(title, 15, cInk, true));
        TextView s = tv(sub, 11, cSub, false);
        s.setPadding(0, dp(2), 0, 0);
        col.addView(s);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arr = tv("›", 18, cMuted, false);
        row.addView(arr);
        row.setOnClickListener(v -> onClick.run());
        return row;
    }

    void aboutCard(LinearLayout pad) {
        TextView sh = tv("关于作者", 13, cSec, false);
        sh.setPadding(0, dp(26), 0, dp(8));
        pad.addView(sh);
        LinearLayout c = card();
        c.setPadding(dp(18), dp(4), dp(18), dp(4));
        c.addView(listRow("J", true, "Jacky2277", "静签作者 · 广东金融学院", this::showAbout));
        View div1 = new View(this);
        div1.setBackgroundColor(cLine);
        c.addView(div1, new LinearLayout.LayoutParams(-1, dp(1)));
        c.addView(listRow("↗", false, "github.com/Jacky2277", "GitHub 主页 · 源码与更新", this::openGithub));
        pad.addView(c, new LinearLayout.LayoutParams(-1, -2));
    }

    void bottomNote(LinearLayout pad) {
        TextView t = tv("静签 Special " + VERSION + " · 仅供技术交流", 11, cMuted, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(26), 0, dp(2));
        pad.addView(t);
        TextView g = tv("github.com/Jacky2277", 11, cMuted, false);
        g.setGravity(Gravity.CENTER);
        g.setPadding(0, dp(2), 0, dp(10));
        pad.addView(g);
    }

    void showAbout() {
        m3Dialog("关于静签",
                "静签 Special " + VERSION + "\n\n作者：Jacky2277\nGitHub：github.com/Jacky2277\n\n" +
                        "仅供技术交流，请勿用于违规用途。\n所有 token 只保存在本机，不会上传。",
                "打开 GitHub", this::openGithub, "关闭", null);
    }

    void showNotesDialog() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(10), dp(20), dp(6));

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setClipChildren(false);
        chips.addView(noteChip("设备状态", cInk2, night ? cLine : 0xFFF2F5FA));

        String accountText;
        int accountFg, accountBg;
        String thisText;
        int thisFg, thisBg;
        if (lastStatus == null) {
            accountText = "读取中"; accountFg = cInk2; accountBg = night ? cLine : 0xFFF2F5FA;
            thisText = "读取中"; thisFg = cInk2; thisBg = night ? cLine : 0xFFF2F5FA;
        } else {
            if (lastStatus.activeCount > 0) {
                accountText = "账号已落库"; accountFg = cOk; accountBg = cOkSoft;
            } else {
                accountText = "账号未落库"; accountFg = cDanger; accountBg = cDangerSoft;
            }
            if (lastStatus.isBoundThisDevice(YgjClient.deviceModel())) {
                thisText = "本机已落库"; thisFg = cOk; thisBg = cOkSoft;
            } else {
                thisText = "本机未绑定"; thisFg = cDanger; thisBg = cDangerSoft;
            }
        }
        chips.addView(noteChip(accountText, accountFg, accountBg));
        chips.addView(noteChip(thisText, thisFg, thisBg));
        body.addView(chips);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setBackground(bg(cWarnSoft, 14));
        hero.setPadding(dp(13), dp(13), dp(13), dp(13));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, -2);
        hlp.topMargin = dp(12);
        body.addView(hero, hlp);

        TextView heroTitle = tv("先读这一段：易班 / 易广金有已知 Bug", 13, cWarn, true);
        hero.addView(heroTitle);
        TextView heroBody = tv("由于易班 / 易广金官方存在诸多 Bug，作者实在不想为其“擦屁股”。"
                + "如果你不想在静签签到、出校之后，回到易班 / 易广金时看到"
                + "“设备已经被绑定，需要联系导员解绑”，或遇到其他异常，"
                + "请按下面的顺序处理。", 12, 0xFF7C4E12, false);
        heroBody.setLineSpacing(dp(4), 1f);
        heroBody.setPadding(0, dp(6), 0, 0);
        hero.addView(heroBody);
        TextView heroMust = tv("推荐使用易班 5.1.8；若你当前版本低于 5.1.8，则无需理会这段文字。", 11.5f, cWarn, true);
        heroMust.setLineSpacing(dp(3), 1f);
        heroMust.setPadding(0, dp(6), 0, 0);
        hero.addView(heroMust);

        noteHeading(body, "操作顺序（共 5 步）", 16);
        String[] steps = {
                "前往本项目地址下载易班 5.1.8 安装包｜仓库暂未提供时，请联系作者",
                "当前易班版本高于 5.1.8：先卸载高版本，再安装 5.1.8｜低于 5.1.8 可忽略",
                "安装后登录易班，再登录易广金，绑定你当前这台设备",
                "后续使用中不要再更新易班 / 易广金",
                "绑定完成后，再返回静签继续使用"
        };
        for (int i = 0; i < steps.length; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.TOP);
            row.setPadding(0, dp(7), 0, dp(3));
            TextView n = tv(String.valueOf(i + 1), 10, cPrimary, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(bg(cAccentSoft, 999));
            row.addView(n, new LinearLayout.LayoutParams(dp(18), dp(18)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(9), 0, 0, 0);
            String[] parts = steps[i].split("｜", 2);
            TextView tx = tv(parts[0], 12, cInk, false);
            tx.setLineSpacing(dp(3), 1f);
            col.addView(tx);
            if (parts.length > 1) {
                TextView su = tv(parts[1], 11, cInk3, false);
                su.setLineSpacing(dp(3), 1f);
                su.setPadding(0, dp(2), 0, 0);
                col.addView(su);
            }
            if (i == 0) {
                LinearLayout link = new LinearLayout(this);
                link.setOrientation(LinearLayout.HORIZONTAL);
                link.setGravity(Gravity.CENTER_VERTICAL);
                link.setBackground(bg(cCard, 8));
                link.setPadding(dp(10), dp(8), dp(10), dp(8));
                LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, -2);
                llp.topMargin = dp(6);
                col.addView(link, llp);
                TextView lc = tv("github.com/Jacky2277\nQuietSign-iOS-Android", 9.5f, cPrimary, false);
                lc.setTypeface(Typeface.MONOSPACE);
                lc.setLineSpacing(dp(2), 1f);
                link.addView(lc, new LinearLayout.LayoutParams(0, -2, 1));
                TextView la = tv("↗", 11, cPrimary, false);
                link.addView(la);
                link.setOnClickListener(v -> openGithub());
            }
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            body.addView(row);
        }

        noteHeading(body, "为什么必须用 5.1.8，并且不再更新", 17);
        notePara(body, "易班 / 易广金的部分高版本会在某些机型上反复校验设备。"
                + "静签本身不会新增绑定，但官方客户端仍可能在你回到易班 / 易广金时弹出"
                + "“设备已经被绑定，需要联系导员解绑”。这不是静签写入了新设备，"
                + "而是官方客户端的 Bug。作者没有精力逐个版本替官方客户端擦屁股，"
                + "所以把“易班 5.1.8 + 不再更新”作为目前最稳的使用组合。");
        notePara(body, "如果你当前版本高于 5.1.8：必须先卸载高版本，再安装 5.1.8；"
                + "否则高版本可能继续覆盖设备校验结果。安装并绑定完成后，"
                + "不要再更新易班或易广金，直接返回静签使用。");

        noteHeading(body, "可能遇到的异常", 15);
        noteBullet(body, "使用完静签，回到易班 / 易广金看到“设备已经被绑定，需要联系导员解绑”。");
        noteBullet(body, "设备机型、绑定状态反复变化，签到页提示“设备不一致”。");
        noteBullet(body, "官方客户端升级后，原本正常的绑定突然失效。");
        noteBullet(body, "遇到以上情况，先按 5.1.8 顺序重做一次；不要反复点真实绑定，也不要在静签里随便写入设备。");

        noteHeading(body, "设备状态说明", 15);
        notePara(body, "active 指账号当前有效的设备绑定记录。静签只做辅助，不修改官方绑定。");
        notePara(body, "本机已落库：签到、出校码正常，静签只读，不写设备表。");
        notePara(body, "账号已落库、本机未绑定：静签借用账号已有 active 身份生成出校码；"
                + "官方易班在本机可能提示“设备不一致”，这是官方客户端的识别问题。");
        notePara(body, "0 active：签到可用；出校码需要一次临时校验，只接受 UUID >36 位，"
                + "且不会写入设备表。");
        notePara(body, "解绑待审批：说明账号已有一条 pending 申请，先等辅导员 / 学院书记处理，"
                + "不要重复提交。");

        noteHeading(body, "绑定与解绑边界", 15);
        noteBullet(body, "正常签到、生成出校码不会新增绑定，也不会产生解绑申请。");
        noteBullet(body, "真实绑定只在 0 active、无 pending、UUID ≤36，并且你主动确认后写入；不要反复点击。");
        noteBullet(body, "A′ 临时校验只用于 0 active + UUID >36；调用前后会复查设备记录，发现新增立即停止。");        noteBullet(body, "入校码请回首页用「跨天返校」生成；出校凭证页只负责出校码。");

        noteHeading(body, "账号与隐私", 15);
        noteBullet(body, "只登录自己的易班账号，不代签、不共享 token / 密码。");
        noteBullet(body, "token 只保存在本机；日志可能含学号、机型，不要公开发布。");
        noteBullet(body, "静签仅供技术交流，请遵守学校考勤规定。");

        bottomSheet("注意事项", "使用前必读 · 建议逐段看完", body,
                "我已知晓", null, null, null, true);
    }

    TextView noteChip(String text, int fg, int bgColor) {
        TextView chip = tv("● " + text, 10.5f, fg, true);
        chip.setBackground(bg(bgColor, 999));
        chip.setPadding(dp(9), dp(4), dp(9), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        chip.setLayoutParams(lp);
        return chip;
    }

    void noteHeading(LinearLayout body, String text, int topDp) {        TextView h = tv(text, 12.5f, cInk, true);
        h.setPadding(0, dp(topDp), 0, dp(5));
        body.addView(h);
    }

    void notePara(LinearLayout body, String text) {
        TextView p = tv(text, 11.5f, cInk2, false);
        p.setLineSpacing(dp(5), 1f);
        p.setPadding(0, dp(4), 0, dp(4));
        body.addView(p);
    }

    void noteBullet(LinearLayout body, String text) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(3), 0, dp(3));
        TextView dot = tv("・", 11, cPrimary, true);
        row.addView(dot, new LinearLayout.LayoutParams(dp(10), -2));
        TextView p = tv(text, 11.5f, cInk2, false);
        p.setLineSpacing(dp(4), 1f);
        row.addView(p, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(row);
    }

    void openGithub() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/Jacky2277")));
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的浏览器", Toast.LENGTH_SHORT).show();
        }
    }

    /** M3 风格对话框：圆角卡片 + pill 按钮，跟随深浅色 */
    Dialog bottomSheet(String title, String sub, View body, String primary,
                       Runnable primaryAct, String secondary, Runnable secondaryAct, boolean tall) {
        final Dialog d = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setDimAmount(0.36f);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setGravity(Gravity.BOTTOM);
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(cCard, 24));

        View handle = new View(this);
        handle.setBackground(bg(night ? 0xFF3A4150 : 0xFFD9DFE8, 2));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(dp(36), dp(4));
        hlp.gravity = Gravity.CENTER_HORIZONTAL;
        hlp.topMargin = dp(8);
        box.addView(handle, hlp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.TOP);
        head.setPadding(dp(20), dp(12), dp(20), 0);
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(title, 20, cInk, true);
        hc.addView(t);
        if (sub != null && !sub.isEmpty()) {
            TextView s = tv(sub, 12, cInk3, false);
            s.setPadding(0, dp(4), 0, 0);
            hc.addView(s);
        }
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = tv("×", 13, cSec, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(bg(cBg, 999));
        close.setOnClickListener(v -> d.dismiss());
        head.addView(close, new LinearLayout.LayoutParams(dp(30), dp(30)));
        box.addView(head, new LinearLayout.LayoutParams(-1, -2));

        if (tall) {
            ScrollView sv = new ScrollView(this);
            sv.setFillViewport(true);
            sv.addView(body, new ViewGroup.LayoutParams(-1, -2));
            box.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        } else {
            box.addView(body, new LinearLayout.LayoutParams(-1, -2));
        }

        if (primary != null) {
            LinearLayout foot = new LinearLayout(this);
            foot.setOrientation(LinearLayout.HORIZONTAL);
            foot.setGravity(Gravity.CENTER_VERTICAL);
            foot.setPadding(dp(20), dp(12), dp(20), dp(20));
            Button p = flatBtn(primary, cPrimary, 0xFFFFFFFF, 999, 13.5f);
            p.setOnClickListener(v -> {
                d.dismiss();
                if (primaryAct != null) primaryAct.run();
            });
            foot.addView(p, new LinearLayout.LayoutParams(0, dp(48), 1f));
            if (secondary != null) {
                foot.addView(new View(this), new LinearLayout.LayoutParams(dp(9), 1));
                Button s = flatBtn(secondary, cCard, cPrimary, 999, 13);
                GradientDrawable sg = bg(cCard, 999);
                sg.setStroke(dp(1), cLine);
                s.setBackground(sg);
                s.setOnClickListener(v -> {
                    d.dismiss();
                    if (secondaryAct != null) secondaryAct.run();
                });
                foot.addView(s, new LinearLayout.LayoutParams(0, dp(48), 1f));
            }
            box.addView(foot, new LinearLayout.LayoutParams(-1, -2));
        }

        int h = tall ? (int) (getResources().getDisplayMetrics().heightPixels * 0.86f) : -2;
        d.setContentView(box, new ViewGroup.LayoutParams(-1, h));
        d.show();
        if (d.getWindow() != null) d.getWindow().setLayout(-1, h);

        box.setAlpha(0f);
        box.setTranslationY(dp(60));
        box.animate().alpha(1f).translationY(0f).setDuration(280)
                .setInterpolator(new DecelerateInterpolator()).start();
        return d;
    }

    /** 居中短对话框，用于确认/结果类提示。 */
    void m3Dialog(String title, String msg, String posText, Runnable posAct, String negText, Runnable negAct) {
        final Dialog d = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(20), dp(24), dp(20), dp(24));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(cCard, 24));
        box.setPadding(dp(22), dp(22), dp(22), dp(16));
        box.setElevation(dp(10));

        box.addView(tv(title, 20, cInk, true));

        if (msg != null && !msg.isEmpty()) {
            TextView m = tv(msg, 13, cSub, false);
            m.setLineSpacing(dp(7), 1f);
            m.setPadding(0, dp(10), 0, 0);
            box.addView(m);
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(18), 0, 0);

        if (negText != null) {
            Button neg = chipBtn(negText);
            neg.setTextSize(14);
            neg.setPadding(dp(16), 0, dp(16), 0);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, dp(44));
            nlp.rightMargin = dp(10);
            row.addView(neg, nlp);
            neg.setOnClickListener(v -> {
                d.dismiss();
                if (negAct != null) negAct.run();
            });
        }
        if (posText != null) {
            Button pos = pill(posText, cPrimary, 24, 14);
            pos.setPadding(dp(18), 0, dp(18), 0);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, dp(48));
            row.addView(pos, plp);
            pos.setOnClickListener(v -> {
                d.dismiss();
                if (posAct != null) posAct.run();
            });
        }

        box.addView(row);
        wrap.addView(box, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(wrap);

        int wpx = (int) (getResources().getDisplayMetrics().widthPixels * 0.88);
        wrap.measure(View.MeasureSpec.makeMeasureSpec(wpx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(0);
            w.setLayout(wpx, Math.max(wrap.getMeasuredHeight(), dp(80)));
        }
        d.show();
    }

    // ---------------- setup ----------------

    void showSetup(boolean expired) {
        gen++;
        qrPage = false;
        clearRoot();
        root.setBackgroundColor(cBg);
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(dp(20), dp(20), dp(20), dp(24));
        root.addView(pad, new LinearLayout.LayoutParams(-1, -2));

        pad.addView(appBar());
        pad.addView(sectionHead("开始使用"));

        LinearLayout card = card();
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        pad.addView(card, new LinearLayout.LayoutParams(-1, -2));

        card.addView(tv("首次使用，填一次 token", 17, cInk, true));
        TextView sub = tv("token 只保存在本机，不会上传", 12, cSub, false);
        sub.setPadding(0, dp(4), 0, dp(12));
        card.addView(sub);

        TextView step = tv(
                "1. 安装抓包工具（ProxyPin / Stream）\n" +
                "2. 易班 App → 易广金 → 出入申报 → 常规出入\n" +
                "3. 在 f.yiban.cn 的请求头里找到 loginToken（32 位）\n" +
                "4. 粘贴到下面，点「开始使用」", 12, cSub, false);
        step.setLineSpacing(dp(6), 1f);
        card.addView(step);

        tokenInput = new EditText(this);
        tokenInput.setHint("粘贴 32 位 loginToken");
        tokenInput.setTextSize(13);
        tokenInput.setSingleLine(true);
        tokenInput.setTextColor(cInk);
        tokenInput.setHintTextColor(cSub);
        tokenInput.setBackground(bg(cCont, 14));
        tokenInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        tokenInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        tokenInput.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(12);
        card.addView(tokenInput, lp);

        Button go = pill("开始使用", cPrimary, 26, 16);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, dp(50));
        glp.topMargin = dp(12);
        card.addView(go, glp);
        go.setOnClickListener(v -> saveToken());

        Button pwdLogin = chipBtn("易班账号密码登录（不用抓包）");
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, dp(46));
        wlp.topMargin = dp(8);
        card.addView(pwdLogin, wlp);
        pwdLogin.setOnClickListener(v -> startActivityForResult(new Intent(this, PwdLoginActivity.class), REQ_LOGIN));

        Button rootBtn = chipBtn("一键读取本机 token（需 root）");
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, dp(46));
        rlp.topMargin = dp(8);
        card.addView(rootBtn, rlp);
        rootBtn.setOnClickListener(v -> readRootToken());

        Button det = chipBtn("详细教程");
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(44));
        dlp.topMargin = dp(8);
        card.addView(det, dlp);
        det.setOnClickListener(v -> showDetail());

        setupHint = tv(expired ? "token 已失效，请重新抓一次并粘贴" : "token 只保存在本机，不会上传", 12,
                expired ? 0xFFE5484D : cSub, false);
        setupHint.setPadding(dp(2), dp(10), dp(2), 0);
        card.addView(setupHint);

        if (!token().isEmpty()) {
            Button back = chipBtn("返回凭证页");
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(44));
            blp.topMargin = dp(12);
            pad.addView(back, blp);
            back.setOnClickListener(v -> showHome());
        }

        bottomNote(pad);
    }

    void showDetail() {
        String msg = "1. 安装 ProxyPin（应用商店搜索，或官网下载 apk）\n" +
                "2. 打开 ProxyPin，点「开始抓包」；首次使用按提示安装 CA 证书（设置 → 安全 → 加密与凭据 → 安装证书 → CA 证书）\n" +
                "3. 保持抓包，打开易班 App → 易广金 → 出入申报 → 常规出入，停在二维码页\n" +
                "4. 回 ProxyPin 停止抓包，找到 f.yiban.cn 的请求（地址里带 iapp378946 或 iapp/index）\n" +
                "5. 点开请求 → 请求头 → 找到 Cookie，复制 loginToken= 后面那 32 位字符（到分号为止，不要带空格）\n" +
                "6. 粘贴到输入框，点「开始使用」\n\n" +
                "token 只保存在本机，不会上传；失效时 App 会提示重新抓取。\n" +
                "抓不到 f.yiban.cn：确认停在二维码页，清空记录后重抓一次。";
        m3Dialog("详细教程", msg, "知道了", null, null, null);
    }

    void readRootToken() {
        setupHint.setText("正在扫描易班内存，请让易班保持已登录…");
        new Thread(() -> {
            String tok = null, err = null;
            try {
                tok = RootToken.fetch();
            } catch (Throwable e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String t = tok, em = err;
            runOnUiThread(() -> {
                if (t != null) {
                    tokenInput.setText(t);
                    setupHint.setText("已读取到 token：" + t);
                    m3Dialog("已读取到 loginToken",
                            t + "\n\n复制下来可以保存/发给别人；点「继续」会自动填入并进入主界面。",
                            "复制", () -> {
                                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                                if (cm != null) {
                                    cm.setPrimaryClip(ClipData.newPlainText("loginToken", t));
                                    Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
                                }
                                saveToken();
                            },
                            "继续", this::saveToken);
                } else {
                    setupHint.setText("读取失败：" + em + "（Magisk 授权弹窗要点允许）");
                }
            });
        }).start();
    }

    void saveToken() {
        String t = tokenInput.getText().toString().trim();
        if (t.length() < 32) {
            setupHint.setText("token 应该是 32 位十六进制字符，检查一下是否复制完整");
            return;
        }
        sp.edit().putString("userToken", t).apply();
        showHome();
    }

    // ---------------- home (v6.9) ----------------

    static class TodayItem {
        String time = "—", name = "", section = "";
        boolean signed = false;
        long startMs = 0;
    }

    static class TodaySnapshot {
        String date = "";
        int week = 0, total = 0, signed = 0;
        final List<TodayItem> items = new ArrayList<>();
    }

    static String ymd(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR),
                c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static String mdWeek(Calendar c) {
        String[] w = {"日", "一", "二", "三", "四", "五", "六"};
        return (c.get(Calendar.MONTH) + 1) + "月" + c.get(Calendar.DAY_OF_MONTH) + "日 周"
                + w[c.get(Calendar.DAY_OF_WEEK) - 1];
    }

    static int approxWeek(Calendar c) {
        Calendar start = (Calendar) c.clone();
        int y = c.get(Calendar.YEAR);
        if (c.get(Calendar.MONTH) < 7) y--;
        start.set(y, Calendar.SEPTEMBER, 1, 0, 0, 0);
        start.set(Calendar.MILLISECOND, 0);
        long d = (c.getTimeInMillis() - start.getTimeInMillis()) / 86400000L;
        return Math.max(1, (int) (d / 7) + 1);
    }

    TodaySnapshot readToday() {
        TodaySnapshot s = new TodaySnapshot();
        Calendar now = Calendar.getInstance();
        s.date = ymd(now);
        s.week = approxWeek(now);
        try {
            String raw = sp.getString("todayCache", "");
            if (!raw.isEmpty()) {
                JSONObject o = new JSONObject(raw);
                if (s.date.equals(o.optString("date"))) {
                    s.week = o.optInt("week", s.week);
                    s.total = o.optInt("total", 0);
                    s.signed = o.optInt("signed", 0);
                    JSONArray arr = o.optJSONArray("items");
                    if (arr != null) for (int i = 0; i < arr.length(); i++) {
                        JSONObject it = arr.optJSONObject(i);
                        if (it == null) continue;
                        TodayItem t = new TodayItem();
                        t.time = it.optString("time", "—");
                        t.name = it.optString("name", "");
                        t.section = it.optString("section", "");
                        t.signed = it.optBoolean("signed", false);
                        t.startMs = it.optLong("startMs", 0);
                        s.items.add(t);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return s;
    }

    void showHome() {
        gen++;
        qrPage = false;
        clearRoot();
        root.setBackgroundColor(cBg);
        setBarColors(cBg, cCard);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(16), dp(18), dp(18));
        root.addView(page, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.TOP);
        LinearLayout brandCol = new LinearLayout(this);
        brandCol.setOrientation(LinearLayout.VERTICAL);
        TextView brand = tv("静签", 24, cInk, true);
        brand.setLetterSpacing(-0.03f);
        brandCol.addView(brand);
        TextView school = tv(studentID.isEmpty() ? "广东金融学院" : "广东金融学院", 11, cInk3, false);
        school.setPadding(0, dp(5), 0, 0);
        brandCol.addView(school);
        head.addView(brandCol, new LinearLayout.LayoutParams(0, -2, 1));

        TextView log = tv("日志", 11.5f, cSub, false);
        log.setPadding(dp(8), dp(6), dp(8), dp(6));
        log.setOnClickListener(v -> openLogs());
        head.addView(log);
        page.addView(head, new LinearLayout.LayoutParams(-1, -2));

        gap(page, 16);

        TodaySnapshot ts = readToday();
        page.addView(todayCard(ts), new LinearLayout.LayoutParams(-1, -2));
        gap(page, 13);
        page.addView(qrEntryCard(), new LinearLayout.LayoutParams(-1, -2));
        gap(page, 13);
        page.addView(recentCard(ts), new LinearLayout.LayoutParams(-1, -2));
        gap(page, 13);

        LinearLayout strip = card(14);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(13), dp(12), dp(13), dp(12));
        View dot = new View(this);
        dot.setBackground(bg(0xFFF59E0B, 999));
        strip.addView(dot, new LinearLayout.LayoutParams(dp(5), dp(5)));
        homeStripText = tv("正在读取设备状态…", 11.5f, cInk2, false);
        homeStripText.setPadding(dp(7), 0, dp(8), 0);
        strip.addView(homeStripText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = tv("›", 16, cInk4, false);
        strip.addView(arrow);
        strip.setOnClickListener(v -> showDeviceStatusSheet());
        page.addView(strip, new LinearLayout.LayoutParams(-1, -2));
        gap(page, 13);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.setClipChildren(false);
        Button q1 = borderBtn("跨天返校");
        Button q2 = borderBtn("更换 token");
        Button q3 = borderBtn("注意事项");
        q1.setOnClickListener(v -> doOverdue());
        q2.setOnClickListener(v -> confirmChangeToken());
        q3.setOnClickListener(v -> showNotesDialog());
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        quick.addView(q1, qlp);
        LinearLayout.LayoutParams qgap = new LinearLayout.LayoutParams(dp(7), 1);
        quick.addView(new View(this), qgap);
        LinearLayout.LayoutParams qlp2 = new LinearLayout.LayoutParams(0, dp(40), 1.18f);
        quick.addView(q2, qlp2);
        quick.addView(new View(this), new LinearLayout.LayoutParams(dp(7), 1));
        quick.addView(q3, new LinearLayout.LayoutParams(0, dp(40), 1f));
        page.addView(quick, new LinearLayout.LayoutParams(-1, -2));

        aboutCard(page);
        TextView ver = tv("静签 Special " + VERSION + " · 仅供技术交流", 11, cMuted, false);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, dp(20), 0, dp(2));
        page.addView(ver);
        refreshDeviceStatus();
    }

    LinearLayout todayCard(TodaySnapshot ts) {
        LinearLayout c = card(18);
        c.setPadding(dp(16), dp(16), dp(16), dp(10));
        c.setElevation(dp(1));

        Calendar now = Calendar.getInstance();
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView d = tv("今天 · " + mdWeek(now), 11, cInk3, false);
        h.addView(d, new LinearLayout.LayoutParams(0, -2, 1));
        TextView wk = tv("第 " + ts.week + " 周", 11, cInk4, false);
        h.addView(wk);
        c.addView(h);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setGravity(Gravity.BOTTOM);
        main.setPadding(0, dp(9), 0, 0);
        TextView num = tv(ts.total > 0 ? String.valueOf(ts.signed) : "—", 29, cInk, true);
        num.setLetterSpacing(-0.03f);
        main.addView(num);
        TextView slash = tv(ts.total > 0 ? "/" + ts.total : "", 12.5f, cInk4, false);
        slash.setPadding(0, 0, dp(6), dp(3));
        main.addView(slash);
        TextView cap = tv(ts.total > 0 ? "今日已签" : "打开签到考勤后显示", 11, cInk3, false);
        cap.setPadding(0, 0, 0, dp(4));
        main.addView(cap);
        c.addView(main);

        LinearLayout bars = new LinearLayout(this);
        bars.setOrientation(LinearLayout.HORIZONTAL);
        bars.setPadding(0, dp(13), 0, 0);
        int segCount = ts.items.size();
        for (int i = 0; i < segCount; i++) {
            View b = new View(this);
            TodayItem it = ts.items.get(i);
            int color = it.signed ? cPrimary : (i == firstPending(ts.items) ? 0xFFB9CCFF : cLine);
            b.setBackground(bg(color, 2));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(4), 1f);
            if (i > 0) lp.leftMargin = dp(5);
            bars.addView(b, lp);
        }
        if (segCount > 0) c.addView(bars);

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        times.setPadding(0, dp(6), 0, 0);
        for (int i = 0; i < segCount; i++) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TodayItem it = ts.items.get(i);
            TextView t = tv(it.time, 11, cInk2, true);
            col.addView(t);
            TextView st = tv(it.signed ? "已签" : "待签", 10.5f,
                    it.signed ? cOk : cPrimary, false);
            st.setPadding(0, dp(1), 0, 0);
            col.addView(st);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.leftMargin = dp(5);
            times.addView(col, lp);
        }
        if (segCount > 0) c.addView(times);

        View line = new View(this);
        line.setBackgroundColor(cLine);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(-1, dp(1));
        lineLp.topMargin = dp(12);
        c.addView(line, lineLp);

        LinearLayout next = new LinearLayout(this);
        next.setOrientation(LinearLayout.HORIZONTAL);
        next.setGravity(Gravity.CENTER_VERTICAL);
        next.setPadding(0, dp(11), 0, dp(3));
        View nd = new View(this);
        nd.setBackground(bg(cPrimary, 999));
        next.addView(nd, new LinearLayout.LayoutParams(dp(5), dp(5)));
        TodayItem ni = null;
        for (TodayItem it : ts.items) if (!it.signed) { ni = it; break; }
        String nextText = ni == null ? (ts.total > 0 ? "今日课程已全部处理" : "打开签到考勤查看今日课程")
                : ("下一节 " + ni.time + (ni.name.isEmpty() ? "" : " · " + ni.name));
        TextView nt = tv(nextText, 11, cInk2, false);
        nt.setPadding(dp(7), 0, dp(6), 0);
        next.addView(nt, new LinearLayout.LayoutParams(0, -2, 1));
        TextView na = tv("去签到", 11, cPrimary, true);
        next.addView(na);
        TextView nArrow = tv("›", 10, cPrimary, false);
        nArrow.setPadding(dp(6), 0, 0, 0);
        next.addView(nArrow);
        next.setOnClickListener(v -> openSign());
        c.addView(next);
        return c;
    }

    int firstPending(List<TodayItem> items) {
        for (int i = 0; i < items.size(); i++) if (!items.get(i).signed) return i;
        return -1;
    }

    LinearLayout qrEntryCard() {
        LinearLayout c = card(18);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(13), dp(13), dp(13), dp(13));
        c.setElevation(dp(1));
        TextView ic = tv("▦", 19, cPrimary, true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(bg(cAccentSoft, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(11), 0, dp(8), 0);
        TextView t = tv("出入校凭证", 14, cInk, true);
        col.addView(t);
        TextView s = tv("60 秒有效 · 出校 / 入校", 11, cInk3, false);
        s.setPadding(0, dp(2), 0, 0);
        col.addView(s);
        c.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        Button go = flatBtn("生成", cAccentSoft, cPrimary, 999, 11);
        go.setPadding(dp(12), 0, dp(12), 0);
        c.addView(go, new LinearLayout.LayoutParams(-2, dp(30)));
        c.setOnClickListener(v -> showQR(false));
        go.setOnClickListener(v -> showQR(false));
        return c;
    }

    LinearLayout recentCard(TodaySnapshot ts) {
        LinearLayout c = card(18);
        c.setPadding(dp(16), dp(12), dp(16), dp(6));
        c.setElevation(dp(1));
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = tv("最近记录", 11, cInk3, true);
        t.setLetterSpacing(0.06f);
        h.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        TextView all = tv("全部", 10, cInk4, false);
        all.setOnClickListener(v -> openSign());
        h.addView(all);
        c.addView(h);

        int added = 0;
        try {
            String raw = sp.getString("lastQr", "");
            if (!raw.isEmpty()) {
                JSONObject o = new JSONObject(raw);
                String type = o.optString("type", "出");
                String time = o.optString("time", "");
                addRecent(c, (type.equals("入") ? "入校凭证" : "出校凭证"), "已生成", time);
                added++;
            }
        } catch (Exception ignored) {
        }
        List<TodayItem> signed = new ArrayList<>();
        for (TodayItem it : ts.items) if (it.signed) signed.add(it);
        signed.sort((a, b) -> Long.compare(b.startMs, a.startMs));
        for (TodayItem it : signed) {
            if (added >= 4) break;
            String title = (it.section.isEmpty() ? it.name : "第 " + it.section + " 节 · 签到");
            addRecent(c, title, "已签", it.time);
            added++;
        }
        if (added == 0) {
            TextView empty = tv("暂无记录", 11.5f, cInk3, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(13), 0, dp(13));
            c.addView(empty);
        }
        return c;
    }

    void addRecent(LinearLayout c, String title, String status, String time) {
        View line = new View(this);
        line.setBackgroundColor(cLine);
        c.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(9), 0, dp(9));
        TextView t = tv(title, 11.5f, cInk2, false);
        t.setMaxLines(1);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        TextView s = tv(status, 10, status.equals("已签") ? cOk : cInk3, true);
        row.addView(s);
        TextView tm = tv(time, 10, cInk4, false);
        tm.setGravity(Gravity.END);
        row.addView(tm, new LinearLayout.LayoutParams(dp(58), -2));
        c.addView(row);
    }

    LinearLayout homeFooter() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(cCard);
        bar.setPadding(dp(16), dp(10), dp(16), dp(14));
        bar.setElevation(dp(8));
        Button gen = flatBtn("生成凭证", cPrimary, 0xFFFFFFFF, 999, 13.5f);
        gen.setOnClickListener(v -> showQR(false));
        Button sign = flatBtn("签到考勤", cAccentSoft, cPrimary, 999, 13.5f);
        sign.setOnClickListener(v -> openSign());
        bar.addView(gen, new LinearLayout.LayoutParams(0, dp(48), 1f));
        bar.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        bar.addView(sign, new LinearLayout.LayoutParams(0, dp(48), 1f));
        return bar;
    }

    void openSign() {
        Intent it = new Intent(this, SignActivity.class);
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, R.anim.slide_up_in, R.anim.stay);
        }
        startActivityForResult(it, REQ_SIGN);
        if (Build.VERSION.SDK_INT < 34) {
            overridePendingTransition(R.anim.slide_up_in, R.anim.stay);
        }
    }

    void showSignSuccessSnackbar(String section, String time, int count) {
        if (shell == null) return;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = bg(cCard, 16);
        g.setStroke(dp(1), cLine);
        card.setBackground(g);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setElevation(dp(10));

        TextView ic = tv("✓", 17, cOk, true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(bg(cOkSoft, 999));
        card.addView(ic, new LinearLayout.LayoutParams(dp(36), dp(36)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        clp.leftMargin = dp(10);
        card.addView(col, clp);
        col.addView(tv("签到成功", 14.5f, cInk, true));
        String sub = count > 1 ? ("共 " + count + " 门课程已提交")
                : ((section == null || section.isEmpty() ? "" : section + " · ")
                + (time == null ? "" : time + " ") + "已提交");
        TextView st = tv(sub.trim(), 10.5f, cInk3, false);
        st.setPadding(0, dp(2), 0, 0);
        col.addView(st);

        TextView look = tv("查看记录", 11.5f, cPrimary, true);
        look.setPadding(dp(8), dp(6), 0, dp(6));
        card.addView(look);

        final PopupWindow pw = new PopupWindow(card,
                getResources().getDisplayMetrics().widthPixels - dp(28),
                ViewGroup.LayoutParams.WRAP_CONTENT, false);
        pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pw.setOutsideTouchable(true);
        pw.setElevation(dp(12));
        look.setOnClickListener(v -> {
            pw.dismiss();
            openLogs();
        });
        pw.showAtLocation(shell, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, dp(20));
        shell.postDelayed(pw::dismiss, 4000);
    }

    void showQR(boolean auto) {
        gen++;
        qrPage = true;
        qrInbound = false;
        clearRoot();
        root.setBackgroundColor(cBg);
        setBarColors(cBg, cCard);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(20), dp(20), dp(24));
        root.addView(page, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = tv("‹", 20, cInk2, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(bg(cCard, 999));
        back.setElevation(dp(1));
        back.setOnClickListener(v -> showHome());
        top.addView(back, new LinearLayout.LayoutParams(dp(32), dp(32)));
        titleView = tv("出校凭证", 17, cInk, true);
        titleView.setPadding(dp(11), 0, 0, 0);
        top.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1));
        stateChip = tv(auto ? "生成中" : "待生成", 10.5f, cPrimary, true);
        stateChip.setBackground(bg(cAccentSoft, 999));
        stateChip.setPadding(dp(10), dp(4), dp(10), dp(4));
        top.addView(stateChip);
        page.addView(top, new LinearLayout.LayoutParams(-1, -2));

        gap(page, 14);

        LinearLayout qrCard = card(22);
        qrCard.setPadding(dp(16), dp(16), dp(16), dp(14));
        qrCard.setElevation(dp(2));
        page.addView(qrCard, new LinearLayout.LayoutParams(-1, -2));

        int side = Math.min(getResources().getDisplayMetrics().widthPixels - dp(88), dp(260));
        LinearLayout qrBox = new LinearLayout(this);
        qrBox.setOrientation(LinearLayout.VERTICAL);
        qrBox.setGravity(Gravity.CENTER_HORIZONTAL);
        qrBox.setPadding(0, dp(4), 0, dp(2));
        qrCard.addView(qrBox, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout qrWrap = new FrameLayout(this);
        qrView = new ImageView(this);
        qrView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrView.setBackgroundColor(0xFFFFFFFF);
        FrameLayout.LayoutParams qf = new FrameLayout.LayoutParams(side - dp(44), side - dp(44));
        qf.gravity = Gravity.CENTER;
        qrWrap.addView(qrView, qf);

        CornerFrame corners = new CornerFrame(this, cPrimary);
        qrWrap.addView(corners, new FrameLayout.LayoutParams(side, side));

        placeholder = tv("点击下方「生成凭证」\n二维码将在这里显示", 12, cSub, false);
        placeholder.setGravity(Gravity.CENTER);
        placeholder.setBackground(bg(cBg, 12));
        FrameLayout.LayoutParams plf = new FrameLayout.LayoutParams(side - dp(44), side - dp(44));
        plf.gravity = Gravity.CENTER;
        qrWrap.addView(placeholder, plf);

        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(side, side);
        qlp.gravity = Gravity.CENTER_HORIZONTAL;
        qrBox.addView(qrWrap, qlp);

        nameView = tv(auto ? "正在加载…" : "还没有生成凭证", 12.5f, cInk2, true);
        nameView.setGravity(Gravity.CENTER);
        nameView.setPadding(0, dp(12), 0, 0);
        qrCard.addView(nameView);

        qrUseView = tv("出校 · 广东金融学院", 10.5f, cInk3, false);
        qrUseView.setGravity(Gravity.CENTER);
        qrUseView.setPadding(0, dp(3), 0, 0);
        qrCard.addView(qrUseView);

        LinearLayout timer = new LinearLayout(this);
        timer.setOrientation(LinearLayout.HORIZONTAL);
        timer.setGravity(Gravity.CENTER_VERTICAL);
        timer.setPadding(0, dp(12), 0, 0);
        progBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progBar.setIndeterminate(false);
        progBar.setMax(1000);
        progBar.setProgress(auto ? 1000 : 0);
        try {
            progBar.setProgressTintList(ColorStateList.valueOf(cPrimary));
            progBar.setProgressBackgroundTintList(ColorStateList.valueOf(cLine));
        } catch (Exception ignored) {
        }
        timer.addView(progBar, new LinearLayout.LayoutParams(0, dp(3), 1f));
        countdownView = tv(auto ? "60 秒" : "待生成", 10, cInk2, false);
        countdownView.setPadding(dp(9), 0, 0, 0);
        timer.addView(countdownView);
        qrCard.addView(timer);

        statusView = tv(auto ? "正在生成…" : "点下方「生成凭证」生成二维码", 10.5f, cInk3, false);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(6), dp(8), dp(6), 0);
        qrCard.addView(statusView);

        LinearLayout tip = new LinearLayout(this);
        tip.setOrientation(LinearLayout.HORIZONTAL);
        tip.setGravity(Gravity.TOP);
        tip.setPadding(dp(4), dp(13), dp(4), 0);
        TextView ti = tv("!", 11, cInk4, true);
        ti.setGravity(Gravity.CENTER);
        ti.setBackground(bg(cLine, 999));
        tip.addView(ti, new LinearLayout.LayoutParams(dp(18), dp(18)));
        LinearLayout tipCol = new LinearLayout(this);
        tipCol.setOrientation(LinearLayout.VERTICAL);
        tipCol.setPadding(dp(7), 0, 0, 0);
        TextView tipB = tv("二维码约 60 秒有效，生成后尽快使用。", 10.5f, cInk2, true);
        tipCol.addView(tipB);
        TextView tipS = tv("仅限本人使用，请勿截图分享。", 10, cInk3, false);
        tipS.setPadding(0, dp(2), 0, 0);
        tipCol.addView(tipS);
        tip.addView(tipCol, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(tip);

        TextView bright = tv("☼  已自动调至最高亮度", 10, cInk4, false);
        bright.setPadding(dp(4), dp(8), 0, 0);
        page.addView(bright);

        gap(page, 14);

        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        refreshBtn = flatBtn(auto ? "刷新二维码" : "生成凭证", cPrimary, 0xFFFFFFFF, 999, 13.5f);
        refreshBtn.setOnClickListener(v -> refresh());
        foot.addView(refreshBtn, new LinearLayout.LayoutParams(-1, dp(48)));
        page.addView(foot, new LinearLayout.LayoutParams(-1, -2));

        if (auto) {
            qrView.setVisibility(View.VISIBLE);
            placeholder.setVisibility(View.GONE);
            refresh();
        } else {
            qrView.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
        }
    }

    void confirmChangeToken() {
        m3Dialog("更换 token", "更换 token 会回到填写页，已保存的 token 不会丢。",
                "更换", () -> showSetup(false), "取消", null);
    }

    void refreshDeviceStatus() {
        if (homeStripText == null) return;
        String tok = token();
        if (tok.isEmpty()) {
            lastStatus = null;
            homeStripText.setText("未登录 · 填入 token 后识别设备");
            return;
        }
        lastStatus = null;
        homeStripText.setText("正在读取设备状态…");
        final String t = tok;
        new Thread(() -> {
            YgjClient.DeviceStatus st;
            try {
                st = new YgjClient().readStatusOnly(t);
            } catch (Throwable e) {
                st = new YgjClient.DeviceStatus();
                st.error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final YgjClient.DeviceStatus fs = st;
            runOnUiThread(() -> {
                if (!t.equals(token())) return;
                lastStatus = fs;
                updateDeviceStatusCard(fs);
            });
        }).start();
    }

    void updateDeviceStatusCard(YgjClient.DeviceStatus st) {
        if (homeStripText == null) return;
        String type;
        if (st == null || (st.error != null && !st.error.isEmpty())) {
            type = "设备状态读取失败";
        } else if (st.pendingCount > 0) {
            type = "解绑待审批";
        } else if (st.activeCount == 0) {
            type = "本机未落库";
        } else if (st.isBoundThisDevice(YgjClient.deviceModel())) {
            type = "本机已落库";
        } else {
            type = "本机未绑定";
        }
        homeStripText.setText(type + " · 查看注意事项");
    }

    void showDeviceStatusSheet() {
        showDeviceStatusDetail();
    }

    String deviceStatusText(YgjClient.DeviceStatus st) {
        if (st == null) return "还没有读取设备状态。点“刷新”读取。";
        if (st.error != null && !st.error.isEmpty()) {
            return "读取失败：" + st.error + "\n静签已使用伪绑定模式，签到/出校不受影响。";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("记录 ").append(st.rows).append(" 条 · active ").append(st.activeCount)
                .append(" · pending ").append(st.pendingCount).append("\n\n");
        if (st.pendingCount > 0) {
            sb.append("有解绑申请待审批。审批前禁止写入新绑定。\n\n");
        }
        if (st.activeCount == 0) {
            sb.append("账号未落库（0 active）。\n")
                    .append("签到可用；出校码需要一次临时校验，只接受 >36 位官方 UUID。\n")
                    .append("临时校验不写入设备表；≤36 位请用真实绑定或官方绑定。\n")
                    .append("官方易班仍会弹绑定提示。\n");
        } else if (st.isBoundThisDevice(YgjClient.deviceModel())) {
            sb.append("本机已落库。\n")
                    .append("绑定设备：").append(st.activeModel).append("\n")
                    .append("UUID：").append(maskUuid(st.activeUuid))
                    .append("（").append(st.activeUuid == null ? 0 : st.activeUuid.length()).append(" 位）\n")
                    .append("静签只读签到，不会修改设备表。\n");
            if (st.uuidTooLong()) sb.append("注意：UUID 超过 36 位。\n");
        } else {
            sb.append("账号已落库，但绑定的是：").append(st.activeModel).append("\n")
                    .append("本机：").append(YgjClient.deviceModel()).append("，未绑定。\n")
                    .append("静签使用伪绑定；官方易班在本机可能显示设备不一致，静签不处理。\n");
        }
        return sb.toString();
    }

    static String maskUuid(String u) {
        if (u == null || u.isEmpty()) return "（无）";
        if (u.length() <= 16) return u;
        return u.substring(0, 8) + "…" + u.substring(u.length() - 4);
    }

    static String maskStudent(String s) {
        if (s == null || s.length() <= 6) return s == null ? "" : s;
        return s.substring(0, 3) + "***" + s.substring(s.length() - 2);
    }

    void saveQrToGallery() {
        if (lastQrBitmap == null) {
            Toast.makeText(this, "还没有可保存的二维码", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 9);
            Toast.makeText(this, "请允许存储权限后再点一次保存", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            String name = "quietsign_" + System.currentTimeMillis() + ".png";
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/静签");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("无法创建相册文件");
            OutputStream os = getContentResolver().openOutputStream(uri);
            if (os == null) throw new Exception("无法写入相册");
            lastQrBitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            }
            Toast.makeText(this, "已保存到相册", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "保存失败：" + (e.getMessage() == null ? "未知错误" : e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    void showDeviceStatusDetail() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), dp(6));

        TextView msg = tv(deviceStatusText(lastStatus), 12, cInk2, false);
        msg.setLineSpacing(dp(6), 1f);
        body.addView(msg);

        TextView actual = tv("本机：" + YgjClient.deviceModel()
                + " · Android " + Build.VERSION.RELEASE
                + " · 易班 " + (installedYibanVersion().isEmpty() ? "未安装/未知" : installedYibanVersion()), 11.5f, cInk3, false);
        actual.setLineSpacing(dp(4), 1f);
        actual.setPadding(0, dp(8), 0, 0);
        body.addView(actual);

        TextView hint = tv("静签正常签到/出校不依赖设备绑定；真实绑定只在主动确认时写入。", 11.5f, cInk3, false);
        hint.setLineSpacing(dp(4), 1f);
        hint.setPadding(0, dp(8), 0, 0);
        body.addView(hint);

        if (lastStatus != null && lastStatus.activeCount == 0 && lastStatus.pendingCount == 0) {
            Button bind = flatBtn("尝试真实绑定", cDangerSoft, cDanger, 999, 12);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(42));
            blp.topMargin = dp(14);
            body.addView(bind, blp);
            bind.setOnClickListener(v -> showRealBindDialog());
        }

        bottomSheet("设备状态", "只读识别 · 不写绑定", body,
                "刷新", () -> {
                    refreshDeviceStatus();
                    Toast.makeText(this, "正在刷新设备状态…", Toast.LENGTH_SHORT).show();
                }, "关闭", null, false);
    }

    EditText bindInput(LinearLayout box, String label, String value, String hint) {
        TextView l = tv(label, 12, cSub, false);
        l.setPadding(0, dp(10), 0, dp(4));
        box.addView(l);
        EditText in = new EditText(this);
        in.setText(value == null ? "" : value);
        in.setHint(hint);
        in.setSingleLine(true);
        in.setTextSize(13);
        in.setTextColor(cInk);
        in.setHintTextColor(cSub);
        in.setTypeface(Typeface.MONOSPACE);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        in.setBackground(bg(cCont, 14));
        in.setPadding(dp(14), dp(10), dp(14), dp(10));
        box.addView(in, new LinearLayout.LayoutParams(-1, dp(48)));
        return in;
    }

    /** 0 active + UUID>36 的临时出校码会话校验：只建会话，不写设备表。 */
    void showTempQrDialog() {
        final Dialog d = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(cCard, 24));
        box.setPadding(dp(22), dp(20), dp(22), dp(16));
        box.addView(tv("临时校验出校码（不写设备表）", 19, cInk, true));

        TextView warn = tv("当前账号 0 active。出校码接口要求一次设备校验；这次只建立临时会话，不新增绑定记录。"
                + "UUID 必须用本机官方易班只读页读取，且必须超过 36 位。", 12, cSub, false);
        warn.setLineSpacing(dp(4), 1f);
        warn.setPadding(0, dp(6), 0, 0);
        box.addView(warn);

        TextView actual = tv("本机：" + YgjClient.deviceModel()
                + " · Android " + Build.VERSION.RELEASE
                + " · 易班 " + (installedYibanVersion().isEmpty() ? "未安装/未知" : installedYibanVersion()), 12, cSub, false);
        actual.setLineSpacing(dp(4), 1f);
        actual.setPadding(0, dp(8), 0, 0);
        box.addView(actual);

        final EditText uuidIn = bindInput(box, "官方 UUID（必须 >36 位）", "", "从本机易班只读页读取，例如 64 位");
        final TextView err = tv("", 12, 0xFFB3261E, false);
        err.setPadding(0, dp(8), 0, 0);
        box.addView(err);

        Button help = chipBtn("如何获取官方 UUID");
        help.setTextSize(12);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-2, dp(38));
        hlp.topMargin = dp(8);
        box.addView(help, hlp);
        help.setOnClickListener(v -> showUuidHelpDialog());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(14), 0, 0);
        Button cancel = chipBtn("取消");
        cancel.setTextSize(14);
        row.addView(cancel, new LinearLayout.LayoutParams(-2, dp(44)));
        cancel.setOnClickListener(v -> d.dismiss());
        Button ok = pill("开始校验", cPrimary, 24, 14);
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(-2, dp(48));
        olp.leftMargin = dp(10);
        row.addView(ok, olp);
        ok.setOnClickListener(v -> {
            String uuid = uuidIn.getText().toString().trim();
            if (uuid.length() <= 36) {
                err.setText("临时校验只接受超过 36 位的 UUID；≤36 位会真实落库，已禁止");
                return;
            }
            if (installedYibanVersion().isEmpty()) {
                err.setText("读取不到易班版本，请先安装/打开官方易班");
                return;
            }
            d.dismiss();
            doTempCheck(uuid);
        });
        box.addView(row);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        wrap.addView(scroll, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(wrap);
        int wpx = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(0);
            w.setLayout(wpx, Math.min((int) (getResources().getDisplayMetrics().heightPixels * 0.9), dp(640)));
        }
        d.show();
    }

    void doTempCheck(String uuid) {
        Toast.makeText(this, "正在做临时设备校验…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            YgjClient.TempResult tr;
            try {
                tr = new YgjClient().tempCheckForQr(token(), uuid,
                        YgjClient.deviceModel(), Build.VERSION.RELEASE, installedYibanVersion());
            } catch (Throwable e) {
                tr = new YgjClient.TempResult();
                tr.code = -99;
                tr.msg = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final YgjClient.TempResult ft = tr;
            runOnUiThread(() -> {
                if (ft.ok) {
                    sp.edit().putString("officialUuid", uuid)
                            .putString("officialModel", YgjClient.deviceModel())
                            .putString("officialSys", Build.VERSION.RELEASE)
                            .putString("officialApp", installedYibanVersion()).apply();
                    refreshDeviceStatus();
                    m3Dialog("临时校验完成",
                            "未新增设备记录，设备表仍是 0 active。\n"
                                    + "UUID：" + maskUuid(uuid) + "（" + uuid.length() + " 位）\n"
                                    + "现在可以尝试生成出校码。若仍提示“无效设备”，说明服务端没有认这次会话，"
                                    + "不会产生绑定，也不会影响官方使用。",
                            "生成凭证", this::refresh, "关闭", null);
                } else {
                    String reason = (ft.msg == null || ft.msg.isEmpty())
                            ? ("code=" + ft.code + " state=" + ft.state) : ft.msg;
                    if (ft.landed) {
                        reason = "临时校验意外新增了设备记录（" + ft.rowsBefore + "→" + ft.rowsAfter
                                + "），已停止。请不要继续使用这条路径，并把运行日志发给我。";
                    }
                    m3Dialog("临时校验未完成", reason, "知道了", null, null, null);
                }
            });
        }).start();
    }

    void showRealBindDialog() {
        final Dialog d = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(cCard, 24));
        box.setPadding(dp(22), dp(20), dp(22), dp(16));
        box.addView(tv("真实绑定（会写入易广金数据库）", 19, cInk, true));

        TextView warn = tv("只在当前这台手机上操作；UUID 必须来自本机易班只读页。超过 36 位服务端不落库，禁止写入。", 12, cSub, false);
        warn.setLineSpacing(dp(4), 1f);
        warn.setPadding(0, dp(6), 0, 0);
        box.addView(warn);

        String actualModel = YgjClient.deviceModel();
        String installed = installedYibanVersion();

        final EditText uuidIn = bindInput(box, "官方 UUID", "", "从本机易班只读页读取，1–36 位");
        final EditText modelIn = bindInput(box, "机型", actualModel, "厂商:型号，例如 vivo:V2463A");
        final EditText sysIn = bindInput(box, "系统版本", Build.VERSION.RELEASE, "例如 16");
        final EditText appIn = bindInput(box, "易班版本", installed, "例如 5.1.8");

        final TextView err = tv("", 12, 0xFFB3261E, false);
        err.setPadding(0, dp(8), 0, 0);
        box.addView(err);

        Button help = chipBtn("如何获取官方 UUID");
        help.setTextSize(12);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-2, dp(38));
        hlp.topMargin = dp(8);
        box.addView(help, hlp);
        help.setOnClickListener(v -> showUuidHelpDialog());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(14), 0, 0);
        Button cancel = chipBtn("取消");
        cancel.setTextSize(14);
        row.addView(cancel, new LinearLayout.LayoutParams(-2, dp(44)));
        cancel.setOnClickListener(v -> d.dismiss());
        Button ok = pill("确认写入", cPrimary, 24, 14);
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(-2, dp(48));
        olp.leftMargin = dp(10);
        row.addView(ok, olp);
        ok.setOnClickListener(v -> {
            String uuid = uuidIn.getText().toString().trim();
            String model = modelIn.getText().toString().trim();
            String sys = sysIn.getText().toString().trim();
            String app = appIn.getText().toString().trim();
            if (uuid.isEmpty() || uuid.length() > 36) {
                err.setText("UUID 为空或超过 36 位，服务端无法写入");
                return;
            }
            if (model.isEmpty() || sys.isEmpty() || app.isEmpty()) {
                err.setText("机型、系统版本、易班版本都不能为空");
                return;
            }
            final String fu = uuid;
            final String fm = model;
            final String fs = sys;
            final String fa = app;
            String mismatch = "";
            if (!fm.equalsIgnoreCase(YgjClient.deviceModel()))
                mismatch += "\n注意：机型与本机（" + YgjClient.deviceModel() + "）不一致，可能是在给另一台手机绑定。";
            if (!fs.equalsIgnoreCase(Build.VERSION.RELEASE))
                mismatch += "\n注意：系统版本与本机（" + Build.VERSION.RELEASE + "）不一致。";
            String actualApp = installedYibanVersion();
            if (!actualApp.isEmpty() && !fa.equals(actualApp))
                mismatch += "\n注意：易班版本与本机（" + actualApp + "）不一致。";
            String text = "即将把以下设备写入易广金数据库：\n"
                    + "UUID：" + fu + "（" + fu.length() + " 位）\n"
                    + "机型：" + fm + "\n"
                    + "系统：" + fs + "\n"
                    + "易班版本：" + fa + "\n\n"
                    + "写入后官方易班应不再弹窗；静签仍使用伪绑定签到，不会重复写。"
                    + mismatch + "\n"
                    + "确认写入？";
            d.dismiss();
            m3Dialog("确认真实绑定", text, "确认写入",
                    () -> doRealBind(fu, fm, fs, fa), "取消", null);
        });
        box.addView(row);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        wrap.addView(scroll, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(wrap);
        int wpx = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(0);
            w.setLayout(wpx, Math.min((int) (getResources().getDisplayMetrics().heightPixels * 0.9), dp(640)));
        }
        d.show();
    }

    void doRealBind(String uuid, String model, String sys, String app) {
        Toast.makeText(this, "正在写入真实设备…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            YgjClient.BindResult br;
            try {
                br = new YgjClient().bindReal(token(), uuid, model, sys, app);
            } catch (Throwable e) {
                br = new YgjClient.BindResult();
                br.code = -99;
                br.msg = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final YgjClient.BindResult fr = br;
            runOnUiThread(() -> {
                if (fr.ok) {
                    sp.edit().putString("officialUuid", uuid)
                            .putString("bindModel", model)
                            .putString("officialAppVersion", app).apply();
                    m3Dialog("真实绑定成功",
                            "记录 " + (fr.activeId.isEmpty() ? "?" : fr.activeId) + " 已 active。\n"
                                    + "UUID：" + maskUuid(uuid) + "\n"
                                    + "机型：" + model + "\n"
                                    + "系统：" + sys + "\n"
                                    + "易班：" + app + "\n\n"
                                    + "请保持易班当前版本，不要升级/清数据。",
                            "知道了", null, null, null);
                } else {
                    String reason = (fr.msg == null || fr.msg.isEmpty())
                            ? ("code=" + fr.code + " state=" + fr.state) : fr.msg;
                    String extra = "\n\n静签仍使用伪绑定；没有产生 pending。";
                    if (fr.code == 2) {
                        if ("2".equals(fr.state)) extra += "\n有解绑申请待审批，审批前不能写入。";
                        else if ("1".equals(fr.state)) extra += "\n账号已有其他 active 设备，静签不处理设备不一致。";
                    }
                    m3Dialog("真实绑定未完成", reason + extra, "知道了", null, null, null);
                }
                refreshDeviceStatus();
            });
        }).start();
    }

    void showUuidHelpDialog() {
        final Dialog d = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(20), dp(24), dp(20), dp(24));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(cCard, 24));
        box.setPadding(dp(22), dp(20), dp(22), dp(16));
        box.addView(tv("如何获取官方 UUID", 19, cInk, true));

        TextView msg = tv("1. 在易班 App 里点「扫一扫」，扫描下面的二维码。\n"
                + "2. 页面会显示 UUID、deviceModel、systemVersion、appVersion。\n"
                + "3. 真实绑定填四个值；0 active 的临时校验只填 UUID（必须 >36 位）。\n\n"
                + "页面只读，不会调用易广金绑定接口。", 13, cSub, false);
        msg.setLineSpacing(dp(5), 1f);
        msg.setPadding(0, dp(8), 0, 0);
        box.addView(msg);

        ImageView qr = new ImageView(this);
        qr.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try {
            qr.setImageBitmap(makeQR("https://aka.doubaocdn.com/s/H3EonRL8Vo", dp(200)));
        } catch (Exception e) {
            Logx.e("ui", "生成只读页二维码失败", e);
        }
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(dp(200), dp(200));
        qlp.gravity = Gravity.CENTER_HORIZONTAL;
        qlp.topMargin = dp(10);
        box.addView(qr, qlp);

        TextView url = tv("页面：https://aka.doubaocdn.com/s/H3EonRL8Vo", 11, cSub, false);
        url.setPadding(0, dp(8), 0, 0);
        box.addView(url);

        Button close = chipBtn("关闭");
        close.setTextSize(14);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, dp(44));
        clp.gravity = Gravity.END;
        clp.topMargin = dp(12);
        box.addView(close, clp);
        close.setOnClickListener(v -> d.dismiss());

        wrap.addView(box, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(wrap);
        int wpx = (int) (getResources().getDisplayMetrics().widthPixels * 0.9);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(0);
            w.setLayout(wpx, -2);
        }
        d.show();
    }

    String installedYibanVersion() {
        try {
            return getPackageManager().getPackageInfo("com.yiban.app", 0).versionName;
        } catch (Throwable t) {
            return "";
        }
    }

    // ---------------- network ----------------

    String cookieHeader() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : cookies.entrySet()) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    void captureCookies(HttpURLConnection c) {
        Map<String, List<String>> hf = c.getHeaderFields();
        for (Map.Entry<String, List<String>> e : hf.entrySet()) {
            if (e.getKey() == null || !"set-cookie".equalsIgnoreCase(e.getKey())) continue;
            for (String line : e.getValue()) {
                if (line == null) continue;
                String kv = line.split(";", 2)[0];
                int i = kv.indexOf('=');
                if (i > 0) cookies.put(kv.substring(0, i).trim(), kv.substring(i + 1).trim());
            }
        }
    }

    static String read(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    Resp req(String method, String url, String body, Map<String, String> extra) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestMethod(method);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "text/html,application/json,application/xhtml+xml,*/*");
        c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
        String cookie = (extra != null && extra.containsKey("Cookie")) ? extra.get("Cookie") : cookieHeader();
        if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        if (extra != null) {
            for (Map.Entry<String, String> e : extra.entrySet()) {
                if (!"Cookie".equals(e.getKey()) && e.getValue() != null) c.setRequestProperty(e.getKey(), e.getValue());
            }
        }
        if (body != null) {
            c.setDoOutput(true);
            byte[] bb = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bb.length);
            if (c.getRequestProperty("Content-Type") == null)
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            OutputStream os = c.getOutputStream();
            os.write(bb);
            os.close();
        }
        Resp r = new Resp();
        r.code = c.getResponseCode();
        captureCookies(c);
        r.location = c.getHeaderField("Location");
        try {
            r.body = read(r.code >= 400 ? c.getErrorStream() : c.getInputStream());
        } catch (Exception ignored) { }
        c.disconnect();
        return r;
    }

    static String form(Map<String, String> m) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : m.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8")).append('=').append(URLEncoder.encode(e.getValue() == null ? "" : e.getValue(), "UTF-8"));
        }
        return sb.toString();
    }

    static String param(String url, String key) {
        try {
            int q = url.indexOf('?');
            if (q < 0) return null;
            for (String kv : url.substring(q + 1).split("&")) {
                int i = kv.indexOf('=');
                if (i > 0 && URLEncoder.encode(key, "UTF-8").equals(kv.substring(0, i)))
                    return java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
            }
        } catch (Exception ignored) { }
        return null;
    }

    String fetchVerify(String tok) throws Exception {
        Map<String, String> h = new HashMap<>();
        h.put("Authorization", "Bearer " + tok);
        h.put("loginToken", tok);
        h.put("AppVersion", "5.2.5");
        h.put("Cookie", "client=iOS; loginToken=" + tok + "; yiban_user_token=" + tok);
        h.put("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        Resp r = req("GET", "https://f.yiban.cn/iapp378946", null, h);
        String loc = r.location;
        if (loc != null && loc.contains("verify_request=")) return param(loc, "verify_request");
        if (loc != null && (loc.contains("act=iapp378946") || loc.contains("/iapp/index"))) {
            if (loc.startsWith("/")) loc = "https://f.yiban.cn" + loc;
            else if (!loc.startsWith("http")) loc = "https://f.yiban.cn/" + loc;
            Resp r2 = req("GET", loc, null, h);
            if (r2.location != null && r2.location.contains("verify_request=")) return param(r2.location, "verify_request");
        }
        return null;
    }

    static String multipartLogin(String verify) {
        String b = "----GDUFBoundary" + System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();
        sb.append("--").append(b).append("\r\nContent-Disposition: form-data; name=\"loginToken\"\r\n\r\n\r\n");
        sb.append("--").append(b).append("\r\nContent-Disposition: form-data; name=\"verify_request\"\r\n\r\n").append(verify).append("\r\n");
        sb.append("--").append(b).append("--\r\n");
        return sb.toString();
    }

    Map<String, String> gh;

    static class QRResult {
        String qr = "", name = "", start = "", end = "", type = "出", oid = "";
    }

    String prepareSession() throws Exception {
        cookies.clear();
        final String tok = token();
        if (tok.isEmpty()) throw new Exception("TOKEN_EMPTY");

        String verify = fetchVerify(tok);
        if (verify == null || verify.isEmpty()) throw new Exception("TOKEN_EXPIRED");

        String b = "----GDUFBoundary" + System.currentTimeMillis();
        String body = "--" + b + "\r\nContent-Disposition: form-data; name=\"loginToken\"\r\n\r\n\r\n"
                + "--" + b + "\r\nContent-Disposition: form-data; name=\"verify_request\"\r\n\r\n" + verify + "\r\n"
                + "--" + b + "--\r\n";
        Map<String, String> lh = new HashMap<>();
        lh.put("Content-Type", "multipart/form-data; boundary=" + b);
        lh.put("X-Requested-With", "XMLHttpRequest");
        lh.put("Cookie", "client=iOS");
        Resp lr = req("POST", BASE + "/Handler/login.ashx?flag=login", body, lh);
        JSONObject lj = new JSONObject(lr.body);
        if (lj.optInt("code") != 0) {
            String yibanUrl = lj.optString("yibanUrl", "");
            if (lj.optInt("code") == 3 && !yibanUrl.isEmpty())
                throw new Exception("NEED_YIBAN_AUTH|" + yibanUrl);
            throw new Exception("ygj 登录失败：" + clean(lj.optString("msg")));
        }
        String goTo = lj.optString("goToUrl", "");
        int si = goTo.indexOf("studentID=");
        String sid = si >= 0 ? goTo.substring(si + 10).split("[^0-9]")[0] : "";
        studentID = sid;
        cookies.put("client", "iOS");
        if (!sid.isEmpty()) cookies.put("studentID", sid);

        gh = new HashMap<>();
        gh.put("X-Requested-With", "XMLHttpRequest");
        gh.put("Referer", BASE + "/ygj2024/student-default.aspx?studentID=" + sid);
        req("GET", BASE + goTo, null, gh);

        req("POST", BASE + "/Handler/device.ashx?flag=getNotice", form(mapOf("studentID", sid)), gh);

        return sid;
    }

    /**
     * 出校码接口不是只认登录态，还要求“本会话已经过一次设备校验”。
     * 这里只做不写入的会话校验：用账号已有 active 记录的精确身份，
     * autoBind=false，且绝不带 studentID（带 studentID 会被服务端当成新绑定请求）。
     * 已实测：active 存在时返回 code 0「该设备已绑定」，记录数不变。
     */
    void attestForQr(String sid) throws Exception {
        Resp sr = req("POST", BASE + "/Handler/device.ashx?flag=getStudentDevice",
                form(mapOf("studentID", sid)), gh);
        JSONArray sa = new JSONObject(sr.body).optJSONArray("data");
        if (sa == null) throw new Exception("设备状态读取失败，无法校验出校码设备");
        JSONObject active = null;
        boolean pending = false;
        for (int i = 0; i < sa.length(); i++) {
            JSONObject o = sa.getJSONObject(i);
            if ("1".equals(o.optString("state"))) {
                active = o;
                break;
            }
            String ask = o.optString("askDelBindDate", "");
            String del = o.optString("delBindDate", "");
            if ("2".equals(o.optString("state")) || (!ask.isEmpty() && del.isEmpty())) pending = true;
        }
        if (active != null) {
            // 已有 active：用它的精确身份做一次不写入的会话校验（绝不带 studentID）。
            String uuid = active.optString("uuid", "");
            if (uuid.isEmpty()) {
                Logx.w("dev", "出校码设备会话：active 记录 UUID 为空，跳过校验");
                return;
            }
            JSONObject dev = new JSONObject();
            dev.put("uuid", uuid);
            dev.put("deviceModel", active.optString("deviceModel", ""));
            dev.put("systemVersion", active.optString("systemVersion", ""));
            dev.put("appVersion", active.optString("appVersion", ""));
            Resp dr = req("POST", BASE + "/Handler/device.ashx?flag=checkBindDevice",
                    form(mapOf("deviceData", dev.toString(), "autoBind", "false")), gh);
            JSONObject dj = new JSONObject(dr.body);
            Logx.i("dev", "出校码设备会话校验 code=" + dj.optInt("code")
                    + " state=" + dj.optString("state")
                    + " msg=" + clean(dj.optString("msg")));
            if (dj.optInt("code") != 0) {
                Logx.w("dev", "出校码设备会话校验未通过，二维码可能失败：" + clean(dj.optString("msg")));
            }
            return;
        }

        // 0 active：A′ 临时会话校验。只允许 >36 位 UUID，服务端写不进 device 表。
        if (pending) throw new Exception("TEMP_PENDING");
        String uuid = sp.getString("officialUuid", "");
        if (uuid.isEmpty()) throw new Exception("NEED_TEMP_UUID");
        if (uuid.length() <= 36) throw new Exception("TEMP_NOT_APPLICABLE");
        String model = sp.getString("officialModel", YgjClient.deviceModel());
        String sys = sp.getString("officialSys", Build.VERSION.RELEASE);
        String app = sp.getString("officialApp", installedYibanVersion());
        JSONObject dev = new JSONObject();
        dev.put("uuid", uuid);
        dev.put("deviceModel", model);
        dev.put("systemVersion", sys);
        dev.put("appVersion", app);
        Logx.i("dev", "出校码临时校验：uuidLen=" + uuid.length() + " model=" + model + " app=" + app);
        Resp dr = req("POST", BASE + "/Handler/device.ashx?flag=checkBindDevice",
                form(mapOf("deviceData", dev.toString(), "autoBind", "true")), gh);
        JSONObject dj = new JSONObject(dr.body);
        int code = dj.optInt("code");
        String state = dj.optString("state");
        String msg = clean(dj.optString("msg"));
        Logx.i("dev", "出校码临时校验响应 code=" + code + " state=" + state + " msg=" + msg);
        Resp ar = req("POST", BASE + "/Handler/device.ashx?flag=getStudentDevice",
                form(mapOf("studentID", sid)), gh);
        JSONArray aa = new JSONObject(ar.body).optJSONArray("data");
        int afterRows = aa == null ? 0 : aa.length();
        int afterActive = 0;
        if (aa != null) for (int i = 0; i < aa.length(); i++) {
            if ("1".equals(aa.getJSONObject(i).optString("state"))) afterActive++;
        }
        Logx.i("dev", "出校码临时校验复查 rows=" + sa.length() + "→" + afterRows
                + " active=" + afterActive);
        if (afterRows > sa.length() || afterActive > 0) {
            Logx.e("dev", "出校码临时校验意外落库，停止；rowsBefore=" + sa.length()
                    + " rowsAfter=" + afterRows + " activeAfter=" + afterActive, null);
            throw new Exception("TEMP_LANDED");
        }
        if (code != 0) throw new Exception("临时设备校验失败：" + msg);
    }

    String findLatestRecord(String sid, String type) {
        try {
            Resp mr = req("POST", BASE + "/Handler/outschool.ashx?flag=getMyOutSchool",
                    form(mapOf("studentID", sid)), gh);
            JSONArray arr = new JSONObject(mr.body).optJSONArray("data");
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (type.equals(o.optString("type", ""))) return o.optString("outSchoolID", "");
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    QRResult loadQRForRecord(String sid, String oid, String type) throws Exception {
        QRResult q = new QRResult();
        q.oid = oid;
        q.type = type;
        String page = BASE + "/ygj2024/outschool/student-outschool.aspx?type="
                + URLEncoder.encode(type, "UTF-8") + "&outSchoolID=" + oid;
        Map<String, String> h = new HashMap<>(gh);
        h.put("Referer", page);
        req("GET", page, null, h);

        Resp pr = req("POST", BASE + "/Handler/outschool.ashx?flag=getPassRecord",
                form(mapOf("studentID", sid, "outSchoolID", oid, "type", type)), h);
        JSONObject pj = new JSONObject(pr.body);
        if (pj.optInt("code") != 0) throw new Exception("读取凭证失败：" + clean(pj.optString("msg")));
        JSONArray arr = pj.optJSONArray("data");
        if (arr == null || arr.length() == 0) throw new Exception("凭证不存在或已过期");
        JSONObject o = arr.getJSONObject(0);
        q.name = o.optString("studentName", o.optString("name", ""));
        q.start = o.optString("startTime", o.optString("startDate", ""));
        q.end = o.optString("endTime", o.optString("endDate", ""));

        Resp qr = req("POST", BASE + "/Handler/outschool.ashx?flag=getQrcode",
                form(mapOf("outSchoolID", oid)), h);
        JSONObject qj = new JSONObject(qr.body);
        if (qj.optInt("code") != 0) throw new Exception("取二维码失败：" + clean(qj.optString("msg")));
        q.qr = qj.optString("qrcode", "");
        if (q.qr.isEmpty()) throw new Exception("二维码为空");
        return q;
    }

    void finishQR(QRResult q, int my) throws Exception {
        final Bitmap bmp = makeQR(q.qr + (System.currentTimeMillis() / 1000L), 720);
        if (!q.name.isEmpty()) lastName = q.name;
        if (!q.start.isEmpty()) lastStart = q.start;
        if (!q.end.isEmpty()) lastEnd = q.end;
        final boolean inbound = "入".equals(q.type);
        final String nm = lastName;
        final String st = lastStart;
        final String tt = timeNow();
        final long endMs = parseTime(lastEnd);
        ui.post(() -> {
            if (my != gen || qrView == null) return;
            titleView.setText(inbound ? "入校凭证" : "出校凭证");
            String who = nm.isEmpty() ? "" : (nm + (studentID.isEmpty() ? "" : " · " + maskStudent(studentID)));
            nameView.setText(who.isEmpty() ? "本人凭证" : who);
            if (qrUseView != null) qrUseView.setText((inbound ? "入校" : "出校") + " · 广东金融学院");
            qrView.setVisibility(View.VISIBLE);
            if (placeholder != null) placeholder.setVisibility(View.GONE);
            if (refreshBtn != null) refreshBtn.setText("刷新二维码");
            if (stateChip != null) stateChip.setText("有效中");
            if (progBar != null) progBar.setProgress(1000);
            qrView.setImageBitmap(bmp);
            lastQrBitmap = bmp;
            endAt = endMs;
            lastInbound = inbound;
            if (statusView != null) statusView.setText("凭证 " + tt + " 生成，每 60 秒自动刷新");
            try {
                JSONObject lo = new JSONObject();
                lo.put("type", inbound ? "入" : "出");
                lo.put("time", tt.substring(0, Math.min(5, tt.length())));
                lo.put("date", dayOf(st));
                sp.edit().putString("lastQr", lo.toString()).apply();
            } catch (Exception ignored) {
            }
            nextRefreshAt = System.currentTimeMillis() + 60000;
            scheduleTick(my);
        });
    }

    void doRefresh(final int my) throws Exception {
        String sid = prepareSession();
        attestForQr(sid);
        Resp ar = req("POST", BASE + "/Handler/outschool.ashx?flag=autoCreateOutSchoolRecord",
                form(mapOf("studentID", sid)), gh);
        JSONObject aj = new JSONObject(ar.body);
        if (aj.optInt("code") != 0) throw new Exception("生成凭证失败：" + clean(aj.optString("msg")));
        String oid = aj.optString("outSchoolID", "");
        String type = aj.optString("type", "出");
        if (type.isEmpty()) type = "出";
        if (oid.isEmpty()) oid = findLatestRecord(sid, type);
        if (oid.isEmpty()) throw new Exception("没有拿到凭证号，请稍后重试");
        outSchoolID = oid;
        recType = type;
        finishQR(loadQRForRecord(sid, oid, type), my);
    }

    void doOverdue() {
        m3Dialog("跨天返校",
                "将向学校提交一条「出校超时（申请进校）」：\n去向：广东省广州市天河区\n日期：今天\n次数：共一次出入\n\n提交后会生成入校凭证。",
                "提交并生成入校码", this::runOverdue, "取消", null);
    }

    void runOverdue() {
        if (busy) return;
        if (!qrPage) showQR(false);
        busy = true;
        final int my = ++gen;
        if (statusView != null) statusView.setText("正在提交出校超时（申请进校）…");
        new Thread(() -> {
            try {
                finishQR(applyOverdueReturn(prepareSession()), my);
            } catch (final Exception e) {
                final String msg = e.getMessage() == null ? "" : e.getMessage();
                ui.post(() -> {
                    if (statusView != null && my == gen) statusView.setText("出错：" + msg);
                    if ("NEED_TEMP_UUID".equals(msg)) showTempQrDialog();
                });
            } finally {
                busy = false;
            }
        }).start();
    }

    QRResult applyOverdueReturn(String sid) throws Exception {
        attestForQr(sid);
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date());
        String addPage = BASE + "/ygj2024/outschool/student-add.aspx";
        Map<String, String> h = new HashMap<>(gh);
        h.put("Referer", addPage);
        req("GET", addPage, null, h);
        Map<String, String> f = mapOf(
                "outSchoolID", "0", "studentID", sid, "days", "1", "passNum", "共一次出入",
                "outType", "CXCS", "outTypeName", "出校超时（申请进校）",
                "outAddress", "广东省广州市天河区", "startDate", today, "endDate", today,
                "linkName", "", "linkPhone", "", "phone", "", "images", "", "picture1", "", "picture2", "");
        Resp sr = req("POST", BASE + "/Handler/outschool.ashx?flag=save", form(f), h);
        JSONObject sj = new JSONObject(sr.body);
        if (sj.optInt("code") != 0) throw new Exception("提交失败：" + clean(sj.optString("msg")));
        String oid = sj.optString("outSchoolID", "");
        if (oid.isEmpty() || "0".equals(oid)) {
            Resp mr = req("POST", BASE + "/Handler/outschool.ashx?flag=getMyOutSchool",
                    form(mapOf("studentID", sid)), h);
            JSONArray arr = new JSONObject(mr.body).optJSONArray("data");
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (o.optString("outTypeName", "").contains("超时") || "入".equals(o.optString("type"))) {
                    oid = o.optString("outSchoolID", "");
                    break;
                }
            }
        }
        if (oid.isEmpty()) throw new Exception("提交成功，但没找到入校凭证，请点刷新重试");
        outSchoolID = oid;
        recType = "入";
        return loadQRForRecord(sid, oid, "入");
    }

    static long parseTime(String s) {
        if (s == null) return 0;
        try {
            String t = s.trim().replace('/', '-');
            if (t.length() >= 19) t = t.substring(0, 19);
            return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).parse(t).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    static String dayOf(String s) {
        if (s == null) return "";
        String t = s.trim().replace('/', '-');
        return t.length() >= 10 ? t.substring(0, 10) : t;
    }

    static String timeNow() {
        return new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
    }

    void scheduleTick(final int my) {
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (countdownView == null || my != gen) return;
                long now = System.currentTimeMillis();
                if (now >= nextRefreshAt) { refresh(); return; }
                if (endAt > 0) {
                    long left = (endAt - now) / 1000;
                    if (left <= 0) {
                        countdownView.setText("该凭证已失效，正在重新生成…");
                        refresh();
                        return;
                    }
                    countdownView.setText(String.format(Locale.US, "%02d 秒", left));
                    if (progBar != null) progBar.setProgress((int) Math.max(0, Math.min(1000, left * 1000 / 60)));
                    statusView.setText(String.format(Locale.US, "该凭证 %02d:%02d 后将失效，请尽快%s校",
                            left / 60, left % 60, lastInbound ? "入" : "出"));
                }
                ui.postDelayed(this, 1000);
            }
        }, 1000);
    }

    void refresh() {
        if (busy) return;
        busy = true;
        final int my = ++gen;
        if (statusView != null) statusView.setText("正在生成…");
        if (stateChip != null) stateChip.setText("生成中");
        new Thread(() -> {
            try {
                doRefresh(my);
            } catch (final Exception e) {
                final String msg = e.getMessage() == null ? "" : e.getMessage();
                ui.post(() -> {
                    if (my != gen) return;
                    if ("TOKEN_EMPTY".equals(msg)) { showSetup(false); return; }
                    if ("TOKEN_EXPIRED".equals(msg)) { showSetup(true); return; }
                    if ("NEED_TEMP_UUID".equals(msg)) {
                        if (statusView != null) statusView.setText("本机未落库，出校码需要一次临时校验");
                        showTempQrDialog();
                        return;
                    }
                    if ("TEMP_NOT_APPLICABLE".equals(msg)) {
                        if (statusView != null) statusView.setText("本机 UUID≤36，临时校验不适用");
                        m3Dialog("本机不能走临时校验",
                                "本机官方 UUID ≤36 位。临时校验只接受 >36 位，否则会真实落库。\n\n"
                                        + "请使用「尝试真实绑定」，或在官方易班完成绑定后再生成出校码。",
                                "知道了", null, null, null);
                        return;
                    }
                    if ("TEMP_PENDING".equals(msg)) {
                        if (statusView != null) statusView.setText("有解绑申请待审批，暂不能临时校验");
                        return;
                    }
                    if ("TEMP_LANDED".equals(msg)) {
                        if (statusView != null) statusView.setText("临时校验意外落库，已停止");
                        m3Dialog("临时校验已停止",
                                "这次临时校验意外新增了设备记录。请不要再继续点生成凭证，并把运行日志里带 dev 的行发给我。",
                                "知道了", null, null, null);
                        return;
                    }
                    if (msg.startsWith("NEED_YIBAN_AUTH|")) {
                        final String url = msg.substring("NEED_YIBAN_AUTH|".length());
                        if (statusView != null) statusView.setText("你的易班账号还没有授权「易广金」");
                        m3Dialog("需要先在易班授权一次",
                                "这个易班账号还没有授权过「易广金」。\n\n点「去授权」会用浏览器打开易班授权页，登录易班账号后点「同意授权」，完成后回到静签再点生成凭证即可。",
                                "去授权", () -> {
                                    try {
                                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                                    } catch (Exception ex) {
                                        Toast.makeText(MainActivity.this, "没有可用的浏览器，请手动打开授权页", Toast.LENGTH_LONG).show();
                                    }
                                },
                                "取消", null);
                        return;
                    }
                    if (statusView != null) statusView.setText("出错：" + msg);
                    if (stateChip != null) stateChip.setText("待生成");
                });
            } finally {
                busy = false;
            }
        }).start();
    }

    static Map<String, String> mapOf(String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    Bitmap makeQR(String text, int size) throws Exception {
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.MARGIN, 1);
        BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints);
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
                bmp.setPixel(x, y, m.get(x, y) ? Color.BLACK : Color.WHITE);
        return bmp;
    }
}
