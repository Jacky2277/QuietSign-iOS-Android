package com.gduf.chuxiao.special;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 易广金会话：登录 + 设备校验，供签到页复用。 */
class YgjClient {

    static final String UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 yiban_iOS/5.2.5(5104)";
    static final String BASE = "https://ygj.gduf.edu.cn";

    /** 官方易班上报的机型格式是「厂商:型号」（冒号），必须一致，否则服务端判「设备不一致」。 */
    static String deviceModel() {
        return android.os.Build.MANUFACTURER + ":" + android.os.Build.MODEL;
    }

    static String shortUrl(String url) {
        try {
            int i = url.indexOf("://");
            int j = url.indexOf('/', i + 3);
            return j > 0 ? url.substring(j) : url;
        } catch (Throwable t) {
            return url;
        }
    }

    final Map<String, String> cookies = new LinkedHashMap<>();
    Map<String, String> gh;
    String studentID = "";
    String lastError = "";

    /** 只读设备状态：只来自 getStudentDevice，不调用 checkBindDevice。 */
    static class DeviceStatus {
        int rows = 0;
        int activeCount = 0;
        int pendingCount = 0;
        String activeId = "";
        String activeUuid = "";
        String activeModel = "";
        String activeSys = "";
        String activeApp = "";
        final List<String> activeModels = new ArrayList<>();
        final List<String> activeUuids = new ArrayList<>();
        String pendingId = "";
        String pendingModel = "";
        String pendingUuid = "";
        String error = "";
        boolean loaded = false;

        boolean isBoundThisDevice(String model) {
            if (model == null) return false;
            for (String m : activeModels) {
                if (m != null && m.equalsIgnoreCase(model)) return true;
            }
            return false;
        }

        boolean uuidTooLong() {
            return activeUuid != null && activeUuid.length() > 36;
        }
    }

    /** 显式真实绑定的结果。code=-2..-5 是本地校验失败，不是服务端 code。 */
    static class BindResult {
        boolean ok = false;
        boolean landed = false;
        int code = -1;
        String state = "";
        String msg = "";
        int activeCount = 0;
        String activeId = "";
        String activeUuid = "";
    }

    DeviceStatus status = new DeviceStatus();

    static class Resp {
        int code;
        String body = "";
        String location = null;
    }

    String cookieHeader() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : cookies.entrySet()) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    void captureCookies(HttpURLConnection c) {
        Map<String, List<String>> hf = c.getHeaderFields();
        for (Map.Entry<String, List<String>> e : hf.entrySet()) {
            if (e.getKey() == null || !"set-cookie".equalsIgnoreCase(e.getKey())) continue;
            for (String line : e.getValue()) {
                if (line == null) continue;
                String kv = line.split(";", 2)[0];
                int i = kv.indexOf('=');
                if (i > 0) cookies.put(kv.substring(0, i).trim(), kv.substring(i + 1).trim());
            }
        }
    }

    static String read(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    Resp req(String method, String url, String body, Map<String, String> extra) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestMethod(method);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "text/html,application/json,application/xhtml+xml,*/*");
        c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
        String cookie = (extra != null && extra.containsKey("Cookie")) ? extra.get("Cookie") : cookieHeader();
        if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        if (extra != null) {
            for (Map.Entry<String, String> e : extra.entrySet()) {
                if (!"Cookie".equals(e.getKey()) && e.getValue() != null) c.setRequestProperty(e.getKey(), e.getValue());
            }
        }
        if (body != null) {
            c.setDoOutput(true);
            byte[] bb = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bb.length);
            if (c.getRequestProperty("Content-Type") == null)
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            OutputStream os = c.getOutputStream();
            os.write(bb);
            os.close();
        }
        Resp r = new Resp();
        r.code = c.getResponseCode();
        captureCookies(c);
        r.location = c.getHeaderField("Location");
        try {
            r.body = read(r.code >= 400 ? c.getErrorStream() : c.getInputStream());
        } catch (Exception ignored) { }
        c.disconnect();
        Logx.i("http", method + " " + shortUrl(url) + " → " + r.code
                + (r.location == null ? "" : " → " + shortUrl(r.location)));
        return r;
    }

    static String form(Map<String, String> m) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : m.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8")).append('=')
              .append(URLEncoder.encode(e.getValue() == null ? "" : e.getValue(), "UTF-8"));
        }
        return sb.toString();
    }

    static Map<String, String> mapOf(String... kv) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    static String param(String url, String key) {
        try {
            int q = url.indexOf('?');
            if (q < 0) return null;
            for (String kv : url.substring(q + 1).split("&")) {
                int i = kv.indexOf('=');
                if (i > 0 && key.equals(kv.substring(0, i)))
                    return java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
            }
        } catch (Exception ignored) { }
        return null;
    }

    String fetchVerify(String tok) throws Exception {
        Map<String, String> h = new HashMap<>();
        h.put("Authorization", "Bearer " + tok);
        h.put("loginToken", tok);
        h.put("AppVersion", "5.2.5");
        h.put("Cookie", "client=iOS; loginToken=" + tok + "; yiban_user_token=" + tok);
        h.put("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        Resp r = req("GET", "https://f.yiban.cn/iapp378946", null, h);
        String loc = r.location;
        if (loc != null && loc.contains("verify_request=")) return param(loc, "verify_request");
        if (loc != null && (loc.contains("act=iapp378946") || loc.contains("/iapp/index"))) {
            if (loc.startsWith("/")) loc = "https://f.yiban.cn" + loc;
            else if (!loc.startsWith("http")) loc = "https://f.yiban.cn/" + loc;
            Resp r2 = req("GET", loc, null, h);
            if (r2.location != null && r2.location.contains("verify_request=")) return param(r2.location, "verify_request");
        }
        return null;
    }

    /** 只登录易广金，不做任何设备校验，返回 studentID。 */
    String loginOnly(String tok) throws Exception {
        cookies.clear();
        Logx.i("ygj", "开始登录易广金（只读，token " + (tok == null ? 0 : tok.length()) + " 位）");
        String verify = fetchVerify(tok);
        if (verify == null || verify.isEmpty()) {
            lastError = "TOKEN_EXPIRED";
            Logx.w("ygj", "fetchVerify 未拿到 verify_request，判 token 失效");
            throw new Exception("TOKEN_EXPIRED");
        }
        Logx.i("ygj", "verify_request 长度 " + verify.length());
        String b = "----GDUFBoundary" + System.currentTimeMillis();
        String body = "--" + b + "\r\nContent-Disposition: form-data; name=\"loginToken\"\r\n\r\n\r\n"
                + "--" + b + "\r\nContent-Disposition: form-data; name=\"verify_request\"\r\n\r\n" + verify + "\r\n"
                + "--" + b + "--\r\n";
        Map<String, String> lh = new HashMap<>();
        lh.put("Content-Type", "multipart/form-data; boundary=" + b);
        lh.put("X-Requested-With", "XMLHttpRequest");
        lh.put("Cookie", "client=iOS");
        Resp lr = req("POST", BASE + "/Handler/login.ashx?flag=login", body, lh);
        JSONObject lj = new JSONObject(lr.body);
        Logx.i("ygj", "login.ashx code=" + lj.optInt("code") + " msg=" + MainActivity.clean(lj.optString("msg")));
        if (lj.optInt("code") != 0) throw new Exception("易广金登录失败：" + MainActivity.clean(lj.optString("msg")));
        String goTo = lj.optString("goToUrl", "");
        int si = goTo.indexOf("studentID=");
        String sid = si >= 0 ? goTo.substring(si + 10).split("[^0-9]")[0] : "";
        studentID = sid;
        cookies.put("client", "iOS");
        if (!sid.isEmpty()) cookies.put("studentID", sid);

        gh = new HashMap<>();
        gh.put("X-Requested-With", "XMLHttpRequest");
        gh.put("Referer", BASE + "/ygj2024/student-default.aspx?studentID=" + sid);
        req("GET", BASE + goTo, null, gh);
        Logx.i("ygj", "登录易广金完成，学号 " + sid);
        return sid;
    }

    /** 只读设备状态：getNotice + getStudentDevice；绝不调用 checkBindDevice。 */
    DeviceStatus readStatus(String sid) {
        DeviceStatus st = new DeviceStatus();
        try {
            try {
                req("POST", BASE + "/Handler/device.ashx?flag=getNotice",
                        form(mapOf("studentID", sid)), gh);
            } catch (Exception e) {
                Logx.w("dev", "getNotice 读取失败，不影响设备状态: " + e.getMessage());
            }
            Resp sr = req("POST", BASE + "/Handler/device.ashx?flag=getStudentDevice",
                    form(mapOf("studentID", sid)), gh);
            JSONObject sj = new JSONObject(sr.body);
            if (sj.optInt("code", 0) != 0) {
                st.error = "getStudentDevice code=" + sj.optInt("code") + " "
                        + MainActivity.clean(sj.optString("msg"));
            }
            JSONArray sa = sj.optJSONArray("data");
            if (sa != null) {
                st.rows = sa.length();
                for (int i = 0; i < sa.length(); i++) {
                    JSONObject o = sa.getJSONObject(i);
                    String state = o.optString("state");
                    String ask = o.optString("askDelBindDate");
                    String del = o.optString("delBindDate");
                    if ("1".equals(state)) {
                        st.activeCount++;
                        String u = o.optString("uuid", "");
                        String m = o.optString("deviceModel", "");
                        st.activeModels.add(m);
                        st.activeUuids.add(u);
                        if (st.activeId.isEmpty()) {
                            st.activeId = o.optString("id", "");
                            st.activeUuid = u;
                            st.activeModel = m;
                            st.activeSys = o.optString("systemVersion", "");
                            st.activeApp = o.optString("appVersion", "");
                        }
                    } else if ("2".equals(state) || (!ask.isEmpty() && del.isEmpty())) {
                        st.pendingCount++;
                        if (st.pendingId.isEmpty()) {
                            st.pendingId = o.optString("id", "");
                            st.pendingModel = o.optString("deviceModel", "");
                            st.pendingUuid = o.optString("uuid", "");
                        }
                    }
                }
            }
            st.loaded = st.error.isEmpty();
            Logx.i("dev", "设备状态 rows=" + st.rows + " active=" + st.activeCount
                    + " pending=" + st.pendingCount
                    + " activeModel=" + (st.activeModel.isEmpty() ? "（无）" : st.activeModel)
                    + " activeUuidLen=" + (st.activeUuid.isEmpty() ? 0 : st.activeUuid.length()));
        } catch (Exception e) {
            st.error = e.getMessage() == null ? e.toString() : e.getMessage();
            Logx.e("dev", "读取设备状态失败", e);
        }
        status = st;
        return st;
    }

    /** 登录 + 只读状态，给首页/设备详情用。 */
    DeviceStatus readStatusOnly(String tok) throws Exception {
        String sid = loginOnly(tok);
        return readStatus(sid);
    }

    /** 登录 + 只读状态，给签到/出校用；状态失败不抛异常。 */
    String prepareReadOnly(String tok) throws Exception {
        String sid = loginOnly(tok);
        readStatus(sid);
        return sid;
    }

    /** 临时设备会话校验的结果。不写 device 表；landed=true 表示服务端意外新增了记录。 */
    static class TempResult {
        boolean ok = false;
        boolean landed = false;
        int code = -1;
        String state = "";
        String msg = "";
        int rowsBefore = 0;
        int activeBefore = 0;
        int rowsAfter = 0;
        int activeAfter = 0;
    }

    /**
     * 0 active 账号的出校码临时会话校验（A′）。
     * 只接受 >36 位 UUID：服务端无法写入，最多建立会话标记，不会产生 active。
     * 绝不带 studentID；autoBind=true 仅用于触发服务端的会话校验分支。
     */
    TempResult tempCheckForQr(String tok, String uuid, String model, String system, String app) throws Exception {
        TempResult tr = new TempResult();
        String u = uuid == null ? "" : uuid.trim();
        String m = model == null ? "" : model.trim();
        String s = system == null ? "" : system.trim();
        String a = app == null ? "" : app.trim();
        if (u.length() <= 36) {
            tr.code = -2;
            tr.msg = "临时校验只接受超过 36 位的 UUID";
            return tr;
        }
        if (m.isEmpty() || s.isEmpty() || a.isEmpty()) {
            tr.code = -2;
            tr.msg = "机型、系统版本、易班版本都不能为空";
            return tr;
        }
        String sid = loginOnly(tok);
        DeviceStatus before = readStatus(sid);
        tr.rowsBefore = before.rows;
        tr.activeBefore = before.activeCount;
        if (!before.error.isEmpty()) {
            tr.code = -3;
            tr.msg = "设备状态读取失败：" + before.error;
            return tr;
        }
        if (before.activeCount > 0) {
            tr.code = -4;
            tr.msg = "账号已有 active 设备，禁止临时校验";
            return tr;
        }
        if (before.pendingCount > 0) {
            tr.code = -5;
            tr.msg = "有解绑申请待审批，禁止临时校验";
            return tr;
        }
        JSONObject dev = new JSONObject();
        dev.put("uuid", u);
        dev.put("deviceModel", m);
        dev.put("systemVersion", s);
        dev.put("appVersion", a);
        Logx.i("dev", "临时出校码校验：uuidLen=" + u.length() + " model=" + m + " sys=" + s + " app=" + a);
        Resp dr = req("POST", BASE + "/Handler/device.ashx?flag=checkBindDevice",
                form(mapOf("deviceData", dev.toString(), "autoBind", "true")), gh);
        JSONObject dj = new JSONObject(dr.body);
        tr.code = dj.optInt("code");
        tr.state = dj.optString("state");
        tr.msg = MainActivity.clean(dj.optString("msg"));
        DeviceStatus after = readStatus(sid);
        tr.rowsAfter = after.rows;
        tr.activeAfter = after.activeCount;
        tr.landed = after.rows > before.rows || after.activeCount > 0;
        tr.ok = tr.code == 0 && !tr.landed;
        if (tr.landed) tr.msg = "临时校验意外新增了设备记录，已停止";
        Logx.i("dev", "临时出校码校验结果 code=" + tr.code + " state=" + tr.state
                + " rows=" + tr.rowsBefore + "→" + tr.rowsAfter
                + " active=" + tr.activeBefore + "→" + tr.activeAfter
                + " landed=" + tr.landed + " msg=" + tr.msg);
        return tr;
    }

    /** 唯一写绑定入口：只允许 active=0、pending=0、UUID<=36，且写入后必须验证 active。 */
    BindResult bindReal(String tok, String uuid, String model, String system, String app) throws Exception {
        BindResult br = new BindResult();
        String u = uuid == null ? "" : uuid.trim();
        String m = model == null ? "" : model.trim();
        String s = system == null ? "" : system.trim();
        String a = app == null ? "" : app.trim();
        if (u.isEmpty() || u.length() > 36) {
            br.code = -2;
            br.msg = "UUID 为空或超过 36 位，服务端无法写入";
            return br;
        }
        if (m.isEmpty() || s.isEmpty() || a.isEmpty()) {
            br.code = -2;
            br.msg = "机型、系统版本、易班版本都不能为空";
            return br;
        }
        String sid = loginOnly(tok);
        DeviceStatus before = readStatus(sid);
        if (!before.error.isEmpty()) {
            br.code = -3;
            br.msg = "设备状态读取失败：" + before.error;
            return br;
        }
        if (before.activeCount > 0) {
            br.code = -4;
            br.msg = "账号已有 active 设备，禁止写入";
            br.activeCount = before.activeCount;
            return br;
        }
        if (before.pendingCount > 0) {
            br.code = -5;
            br.msg = "有解绑申请待审批，禁止写入";
            return br;
        }
        JSONObject dev = new JSONObject();
        dev.put("uuid", u);
        dev.put("deviceModel", m);
        dev.put("systemVersion", s);
        dev.put("appVersion", a);
        Logx.i("dev", "真实绑定写入：uuidLen=" + u.length() + " model=" + m + " sys=" + s + " app=" + a);
        Resp dr = req("POST", BASE + "/Handler/device.ashx?flag=checkBindDevice",
                form(mapOf("deviceData", dev.toString(), "autoBind", "true")), gh);
        JSONObject dj = new JSONObject(dr.body);
        br.code = dj.optInt("code");
        br.state = dj.optString("state");
        br.msg = MainActivity.clean(dj.optString("msg"));
        if (br.code != 0) {
            Logx.w("dev", "真实绑定失败 code=" + br.code + " state=" + br.state + " msg=" + br.msg);
            return br;
        }
        DeviceStatus after = readStatus(sid);
        br.activeCount = after.activeCount;
        br.activeId = after.activeId;
        br.activeUuid = after.activeUuid;
        boolean matched = false;
        for (String au : after.activeUuids) {
            if (au != null && au.equalsIgnoreCase(u)) {
                matched = true;
                break;
            }
        }
        br.landed = matched;
        br.ok = matched;
        if (!matched) br.msg = "服务端返回 code 0，但没有生成匹配的 active 记录";
        Logx.i("dev", "真实绑定结果 code=" + br.code + " landed=" + br.landed
                + " active=" + br.activeCount + " activeUuid=" + br.activeUuid);
        return br;
    }
}
